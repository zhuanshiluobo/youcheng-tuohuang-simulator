# 地图高亮贴图包 v1.2

**v1.2 更新：可选改为电光蓝，已选保留洋红；柔光从实线最外缘向外扩散。继续保留相对 v1.0 的两倍实线宽度。贴图文件名、逻辑尺寸、pivot 和全部坐标沿用原版，可覆盖替换素材。**

用于《游城拓荒：铸基者》的三人、四人地图。资源点、单／双槽航道、影响力槽位各提供“可选择／已选择”两种状态，共 8 个形状状态组合。PNG 中央透明，柔光向外扩散。

本次修改见 [v1.2 更新说明](PATCH-v1.2.md)。

## 先看这两份文档

- [四人地图使用说明及全部坐标](docs/Four-Player-Guide.md)：22 个资源点、22 个航道、77 个槽位。
- [三人地图使用说明及全部坐标](docs/Three-Player-Guide.md)：18 个资源点、20 个航道、65 个槽位。

![实际 PNG 叠图对比](previews/highlight-comparison.png)

## 文件位置

| 目录／文件 | 内容 |
|---|---|
| `assets/png-4x/` | 8 张高分辨率透明贴图，推荐用于放大的地图 |
| `assets/png-2x/` | 同一套 2× 贴图 |
| `assets/png-1x/` | 原图像素尺度的贴图 |
| `assets/svg/` | 8 个可编辑矢量源文件，包含外发散柔光 |
| `data/assets.json` | 逻辑尺寸、留白、pivot、轮廓多边形和文件路径 |
| `data/four-player-map.json` | 四人地图全部中心坐标与槽位归属 |
| `data/three-player-map.json` | 三人地图全部中心坐标与槽位归属 |
| `data/*-resources.csv` | 两张地图各自的资源点坐标 |
| `data/*-routes.csv` | 两张地图各自的航道坐标和类型 |
| `data/*-influence-slots.csv` | 两张地图各自的槽位坐标 |
| `previews/` | 两张地图的完整叠图和逐个目标检查图 |
| `QA-*.json` | 检查记录 |
| `tools/overlay.py` | 使用交付 PNG 和 JSON，重新叠回用户原图 |
| `tools/render-assets.mjs` | 修改 SVG 后，重新导出 1×、2×、4× PNG |

## 尺寸要点

| 贴图类别 | 文件前缀 | 外轮廓宽×高 | 四侧留白 | 完整贴图逻辑宽×高 | 4× PNG 分辨率 |
|---|---|---:|---:|---:|---:|
| 资源点 | `resource` | 202×208 | 20 | **242×248** | 968×992 |
| 单槽航道 | `route-single` | 118×64 | 16 | **150×96** | 600×384 |
| 双槽航道 | `route-double` | 137×64 | 16 | **169×96** | 676×384 |
| 影响力槽位 | `influence` | 34×34 | 12 | **58×58** | 232×232 |

所有贴图中心 pivot 为 `(0.5,0.5)`。读取坐标表放置后，按“完整贴图逻辑宽×高”乘地图缩放设置显示大小。不要把 4× PNG 的像素数当成逻辑尺寸，不要裁掉四侧透明留白。

`available` 是电光蓝可选择，`selected` 是洋红已选择；两者均增加深色衬边。不可选择时隐藏高亮。B-01 按普通资源点处理。三人／四人坐标分别以完整原图的左下角为原点，地图共用贴图但不共用位置。

## 复现叠图

工具只依赖 Python 与 Pillow；原始地图不放入此包，使用本次上传的 `四人.jpg` 或 `三人.jpg`。

```bash
python tools/overlay.py --map four-player --source /path/to/四人.jpg --kind resource --state selected --out four-resources.png
python tools/overlay.py --map three-player --source /path/to/三人.jpg --kind route --state available --out three-routes.png
```

`--kind` 支持 `resource`、`route`、`influence`、`all`。工具将检查原图尺寸与 SHA-256，避免把一张地图的坐标误套到另一张地图。正式使用无需运行这些工具，直接导入 PNG 与 JSON 即可。

SVG 已包含全部图形和柔光。需要重新导出时，在可导入 `sharp` 的 Node 环境运行 `node tools/render-assets.mjs`；运行会覆盖包内三个 PNG 目录的同名文件。
