// Requires a Node environment with the "sharp" package installed.
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import sharp from 'sharp';
const root = fileURLToPath(new URL('..', import.meta.url));
for (const name of (await fs.readdir(path.join(root,'assets/svg'))).filter(n=>n.endsWith('.svg'))) {
  const input = await fs.readFile(path.join(root,'assets/svg',name));
  for (const scale of [1,2,4]) {
    const dir=path.join(root,`assets/png-${scale}x`);
    await fs.mkdir(dir,{recursive:true});
    await sharp(input,{density:72*scale}).png().toFile(path.join(dir,name.replace('.svg',`@${scale}x.png`)));
  }
}
console.log('Rendered 24 PNGs from the 8 SVG masters.');
