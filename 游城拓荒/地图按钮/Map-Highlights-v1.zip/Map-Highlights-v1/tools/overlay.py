"""Rebuild an exact-size map overlay from the shipped PNGs and coordinates."""
from pathlib import Path
import argparse, hashlib, json
from PIL import Image

root = Path(__file__).resolve().parents[1]
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--map', choices=['four-player','three-player'], required=True)
p.add_argument('--source', type=Path, required=True)
p.add_argument('--kind', choices=['resource','route','influence','all'], default='all')
p.add_argument('--state', choices=['available','selected'], default='available')
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
data = json.loads((root/'data'/f'{a.map}-map.json').read_text(encoding='utf-8'))
raw = a.source.read_bytes()
if hashlib.sha256(raw).hexdigest() != data['source']['sha256']:
    p.error('Source image does not match this coordinate table (SHA-256 differs).')
source = Image.open(a.source).convert('RGBA')
if source.size != (2048,2048):
    p.error('Expected the full 2048 x 2048 map.')
canvas = source.resize((4096,4096), Image.Resampling.LANCZOS)
items = {'resource':data['resources'], 'route':data['routes'], 'influence':data['influence_slots']}
cache = {}
for kind, rows in items.items():
    if a.kind not in (kind,'all'): continue
    for row in rows:
        name = f"{row['asset_key']}-{a.state}@2x.png"
        if name not in cache:
            cache[name] = Image.open(root/'assets/png-2x'/name).convert('RGBA')
        sprite = cache[name]
        x = row['x']*2 - sprite.width/2
        y = (2048-row['y'])*2 - sprite.height/2
        canvas.alpha_composite(sprite, (round(x),round(y)))
a.out.parent.mkdir(parents=True, exist_ok=True)
canvas.resize((2048,2048),Image.Resampling.LANCZOS).convert('RGB').save(a.out)
print(a.out)
