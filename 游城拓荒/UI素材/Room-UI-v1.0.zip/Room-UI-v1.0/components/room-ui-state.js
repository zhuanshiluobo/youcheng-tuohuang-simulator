(function(root){
  'use strict';
  const seatColors=['#5FD200','#FFBF00','#006CFF','#EC0000'];
  const clone=value=>JSON.parse(JSON.stringify(value));
  function occupiedSeats(room){return room.seats.filter(s=>s.status==='occupied'&&s.occupant!=null);}
  function occupiedCount(room){return occupiedSeats(room).length;}
  function isHost(room,actorId=room.viewerId){return actorId===room.hostId;}
  function normalizeRoom(room){
    const next=clone(room);
    if(next.seats.length!==4)throw new Error('The room has exactly four fixed-color seats.');
    next.seats.forEach((seat,i)=>{
      if(!['open','closed','occupied'].includes(seat.status))throw new Error('Unknown seat state.');
      if((seat.status==='occupied')!==(seat.occupant!=null))throw new Error('Seat state and occupant disagree.');
      seat.color=seatColors[i];
    });
    if(!['three-player','four-player'].includes(next.mapId))throw new Error('Unknown map.');
    // This is a one-way constraint, not player-count-based map selection.
    if(occupiedCount(next)===4)next.mapId='four-player';
    return next;
  }
  function mapOptions(room){return [
    {id:'three-player',enabled:isHost(room)&&occupiedCount(room)<4,selected:room.mapId==='three-player',reason:occupiedCount(room)===4?'four-occupied-seats':isHost(room)?null:'host-only'},
    {id:'four-player',enabled:isHost(room),selected:room.mapId==='four-player',reason:isHost(room)?null:'host-only'}
  ];}
  function hostOnly(room,actorId){if(!isHost(room,actorId))throw new Error('Host only.');}
  function setMap(room,mapId,actorId=room.viewerId){
    hostOnly(room,actorId);
    if(!['three-player','four-player'].includes(mapId))throw new Error('Unknown map.');
    if(occupiedCount(room)===4&&mapId!=='four-player')throw new Error('Four occupants require the four-player map.');
    const next=clone(room);next.mapId=mapId;return normalizeRoom(next);
  }
  function removePlayer(room,seatId,actorId=room.viewerId){
    hostOnly(room,actorId);const next=clone(room);const seat=next.seats.find(s=>s.id===seatId);
    if(!seat||seat.status!=='occupied'||!seat.occupant)throw new Error('Occupied seat required.');
    if(seat.occupant.id===room.hostId)throw new Error('Use the existing leave/host-transfer flow for the host.');
    seat.occupant=null;seat.status='open';return normalizeRoom(next);
  }
  function setSeatOpen(room,seatId,open,actorId=room.viewerId){
    hostOnly(room,actorId);const next=clone(room);const seat=next.seats.find(s=>s.id===seatId);
    if(!seat||seat.occupant||seat.status==='occupied')throw new Error('Cannot close an occupied seat. Remove the player separately.');
    seat.status=open?'open':'closed';return normalizeRoom(next);
  }
  function seatActions(room,seat){
    if(seat.status==='occupied')return {changeSeat:seat.occupant.id===room.viewerId,remove:isHost(room)&&seat.occupant.id!==room.hostId,invite:false,hotseat:false,ai:false,close:false,reopen:false};
    const editable=isHost(room);return {changeSeat:false,remove:false,invite:editable&&seat.status==='open',hotseat:editable&&seat.status==='open',ai:editable&&seat.status==='open',close:editable&&seat.status==='open',reopen:editable&&seat.status==='closed'};
  }
  function footerAction(room){
    if(isHost(room))return {id:'start',label:'开始游戏',icon:'start',family:'accent',enabled:room.canStart===true};
    const own=room.seats.find(s=>s.occupant&&s.occupant.id===room.viewerId);
    if(!own)return null;
    return own.occupant.ready?{id:'cancel-ready',label:'取消准备',icon:'close',family:'neutral',enabled:true}:{id:'ready',label:'准备',icon:'check',family:'accent',enabled:room.canReady!==false};
  }
  function toggleReady(room,actorId=room.viewerId){
    if(isHost(room,actorId))throw new Error('Host uses the start action.');
    const next=clone(room);const own=next.seats.find(s=>s.occupant&&s.occupant.id===actorId);
    if(!own)throw new Error('No occupied seat for this player.');
    if(!own.occupant.ready&&room.canReady===false)throw new Error('Readiness is currently unavailable.');
    own.occupant.ready=!own.occupant.ready;return normalizeRoom(next);
  }
  function seatChangeIntent(room,targetSeatId,actorId=room.viewerId){
    const from=room.seats.find(s=>s.occupant&&s.occupant.id===actorId);const target=room.seats.find(s=>s.id===targetSeatId);
    if(!from||!target||target.id===from.id||target.status==='closed')throw new Error('Unavailable target seat.');
    return {type:target.occupant?'request-seat-swap':'request-seat-move',actorId,fromSeatId:from.id,targetSeatId:target.id,targetPlayerId:target.occupant?.id??null,targetColor:seatColors[room.seats.indexOf(target)]};
  }
  // Call only after the host/server has accepted the intent. No request auto-acceptance here.
  function applyAcceptedSeatChange(room,fromSeatId,toSeatId){
    const next=clone(room);const a=next.seats.find(s=>s.id===fromSeatId),b=next.seats.find(s=>s.id===toSeatId);
    if(!a||!b||!a.occupant||a.id===b.id||b.status==='closed')throw new Error('Invalid accepted move.');
    [a.occupant,b.occupant]=[b.occupant,a.occupant];a.status=a.occupant?'occupied':'open';b.status='occupied';return normalizeRoom(next);
  }
  function passwordControl(room){return {visible:isHost(room),label:room.isProtected?'修改密码':'设置密码',icon:'lock'};}
  function copyRoomNumber(room){if(typeof room.roomNumber!=='string')throw new Error('Keep the room number as a string.');return room.roomNumber;}
  const api={seatColors,occupiedSeats,occupiedCount,isHost,normalizeRoom,mapOptions,setMap,removePlayer,setSeatOpen,seatActions,footerAction,toggleReady,seatChangeIntent,applyAcceptedSeatChange,passwordControl,copyRoomNumber};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;root.RoomUIState=api;
})(typeof globalThis!=='undefined'?globalThis:this);
