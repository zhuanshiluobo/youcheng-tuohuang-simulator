(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.PlayerSelection = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  function normalize(input) {
    const mode = input.mode || 'single';
    if (!['single', 'multiple'].includes(mode)) throw new Error('Unknown selection mode');
    const players = (input.players || []).map(p => ({...p, eligible: p.eligible !== false}));
    if (players.length > 4) throw new Error('This game window supports up to four players');
    if (players.some(p => typeof p.id !== 'string' || !p.id)) throw new Error('Player id must be a nonempty string');
    if (new Set(players.map(p => p.id)).size !== players.length) throw new Error('Duplicate player id');
    const min = input.min === undefined ? 1 : input.min;
    const max = input.max === undefined ? (mode === 'single' ? 1 : Math.max(1, players.length)) : input.max;
    if (!Number.isInteger(min) || !Number.isInteger(max) || min < 0 || max < min || max > 4 || (mode === 'single' && max !== 1)) throw new Error('Invalid selection bounds');
    const valid = new Set(players.filter(p => p.eligible).map(p => p.id));
    const selectedIds = [...new Set(input.selectedIds || [])].filter(id => valid.has(id)).slice(0, max);
    return {...input, mode, min, max, players, selectedIds, allowCancel: input.allowCancel !== false};
  }
  function canConfirm(input) {
    const s = normalize(input);
    return s.selectedIds.length >= s.min && s.selectedIds.length <= s.max;
  }
  function toggle(input, id) {
    const s = normalize(input), p = s.players.find(p => p.id === id);
    if (!p || !p.eligible) return {state: s, changed: false, reason: p?.disabledReason || '该玩家本次不可选择'};
    const chosen = s.selectedIds.includes(id);
    if (s.mode === 'single') {
      if (chosen && s.min > 0) return {state: s, changed: false, reason: ''};
      return {state: {...s, selectedIds: chosen ? [] : [id]}, changed: true, reason: ''};
    }
    if (chosen) return {state: {...s, selectedIds: s.selectedIds.filter(v => v !== id)}, changed: true, reason: ''};
    if (s.selectedIds.length >= s.max) return {state: s, changed: false, reason: '已达选择上限，请先取消一位已选玩家'};
    return {state: {...s, selectedIds: [...s.selectedIds, id]}, changed: true, reason: ''};
  }
  function instruction(input) {
    const s = normalize(input);
    if (s.min === s.max) return `请选择 ${s.min} 名玩家`;
    if (s.min === 0) return `请选择最多 ${s.max} 名玩家（可不选）`;
    return `请选择 ${s.min} 至 ${s.max} 名玩家`;
  }
  function hint(input) {
    const s = normalize(input), count = s.selectedIds.length;
    if (s.players.filter(p => p.eligible).length < s.min) return '可选玩家不足，无法满足本次选择要求';
    if (count < s.min) return `还需选择 ${s.min - count} 名玩家`;
    return s.mode === 'single' ? '点击其他玩家可更换选择' : '点击已选玩家可取消选择';
  }
  function confirm(input) {
    const s = normalize(input);
    if (!canConfirm(s)) throw new Error('Selection does not meet required count');
    return {type: 'confirm-player-selection', playerIds: [...s.selectedIds]};
  }
  function cancel(input, reason = 'cancel-button') {
    if (!normalize(input).allowCancel) return null;
    return {type: 'cancel-player-selection', reason};
  }
  return {normalize, canConfirm, toggle, instruction, hint, confirm, cancel};
});
