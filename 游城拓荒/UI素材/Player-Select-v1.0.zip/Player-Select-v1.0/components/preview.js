(() => {
  'use strict';
  const ui=PlayerSelection,{assets,layout:C,sample}=PlayerSelectExample;
  const modal=document.getElementById('modal'),stage=document.getElementById('stage'),viewport=document.getElementById('viewport'),picker=document.getElementById('preset'),result=document.getElementById('result');
  let state,feedback='',opened=false;
  function rect(el,r){Object.assign(el.style,{left:r[0]+'px',top:r[1]+'px',width:r[2]+'px',height:r[3]+'px'});return el;}
  function layer(key,r,parent=modal){
    const a=assets[key],slice=a.sliceLTRB,el=document.createElement(slice.some(Boolean)?'div':'img');el.className='layer';rect(el,r);
    if(slice.some(Boolean))Object.assign(el.style,{borderStyle:'solid',borderColor:'transparent',borderWidth:slice.map(v=>v+'px').join(' '),borderImageSource:`url("${a.path}")`,borderImageSlice:slice.join(' ')+' fill',borderImageRepeat:'stretch'});
    else{el.src=a.path;el.alt='';}
    parent.append(el);return el;
  }
  function text(value,r,size,parent=modal,color='#302F2A',center=false){const el=document.createElement('div');el.className='text';el.textContent=value;rect(el,r);el.style.fontSize=size+'px';el.style.color=color;if(center)el.style.justifyContent='center';parent.append(el);return el;}
  function button(family,label,r,handler,disabled=false){
    const b=document.createElement('button');b.type='button';b.className='button';b.disabled=disabled;rect(b,r);modal.append(b);
    const assetKey=st=>family+'-'+(family==='close'&&st==='normal'?'default':st);
    let sprite=layer(assetKey(disabled?'disabled':'normal'),[0,0,r[2],r[3]],b);
    const t=document.createElement('span');t.className='label';t.textContent=label;t.style.color=disabled?'#A59C86':family==='cancel'?'#E7DEC9':'#302B23';b.append(t);
    function show(st){sprite.remove();sprite=layer(assetKey(st),[0,0,r[2],r[3]],b);b.prepend(sprite);}
    if(!disabled){b.addEventListener('mouseenter',()=>show('hover'));b.addEventListener('mouseleave',()=>show('normal'));b.addEventListener('pointerdown',()=>show('pressed'));b.addEventListener('pointerup',()=>show('hover'));b.addEventListener('click',handler);}
    return b;
  }
  function finish(event){if(!event)return;opened=false;modal.hidden=true;result.textContent=event.type==='confirm-player-selection'?'已确认玩家 ID：'+(event.playerIds.join('、')||'无'):'已取消本次玩家选择';window.dispatchEvent(new CustomEvent(event.type,{detail:event}));document.getElementById('reopen').focus();}
  function render(focusId){
    state=ui.normalize(state);modal.replaceChildren();modal.hidden=false;opened=true;
    layer('dim-overlay',[0,0,1920,1080]);layer('window-fill',C.window);layer('window-frame',C.window);layer('accent',C.headerAccent);layer('icon-players-dark',C.headerIcon);
    text(state.title,C.title,38).style.fontWeight='500';text(ui.instruction(state),C.subtitle,25);layer('divider',C.headerDivider);layer('divider',C.footerDivider);
    if(state.allowCancel){const close=button('close','',C.close,()=>finish(ui.cancel(state,'close-button')));close.setAttribute('aria-label','取消并关闭');layer('icon-close-dark',[18,14,28,28],close);}
    const n=state.players.length,sx=960-(n*284+Math.max(0,n-1)*32)/2;
    if(!n)text('没有可选择的玩家',[550,490,820,100],28,modal,'#827963',true);
    state.players.forEach((p,i)=>{
      const selected=state.selectedIds.includes(p.id),st=!p.eligible?'disabled':selected?'selected':'default';
      const b=document.createElement('button');b.type='button';b.className='choice';b.dataset.playerId=p.id;rect(b,[sx+i*316,370,284,320]);b.setAttribute('aria-pressed',String(selected));b.setAttribute('aria-disabled',String(!p.eligible));b.setAttribute('aria-label',`${p.name}，${p.color}，${selected?'已选':'未选'}${p.eligible?'':'，'+(p.disabledReason||'本次不可选择')}`);modal.append(b);
      layer('option-fill-'+st,[0,0,284,320],b);layer('avatar-fill',C.avatarLocal,b);layer('icon-empty-seat-muted',[96,64,92,92],b);
      const portrait=document.createElement('img');portrait.className='layer portrait';portrait.alt='';portrait.src=p.avatar||'';rect(portrait,C.avatarImageLocal);if(!p.eligible)portrait.style.opacity='.46';portrait.addEventListener('error',()=>portrait.hidden=true);b.append(portrait);layer('avatar-frame',C.avatarLocal,b);
      const name=text(p.name,C.nameLocal,26,b,p.eligible?'#302F2A':'#827963');name.classList.add('name');name.title=p.name;
      layer('marker-'+p.color,C.markerLocal,b);text({green:'绿色标记',yellow:'黄色标记',blue:'蓝色标记',red:'红色标记'}[p.color],C.markerLabelLocal,20,b).classList.add('colorname');
      if(p.isSelf)text('你',C.selfLabelLocal,20,b,'#827963');
      if(!p.eligible){layer('icon-lock-muted',[238,14,28,28],b);text(p.disabledReason||'本次不可选择',C.disabledReasonLocal,18,b,'#827963',true);}
      else{layer(selected?'checkbox-checked':'checkbox-unchecked',C.selectionLocal,b);if(selected)layer('icon-check-dark',[240,16,24,24],b);}
      let frame=layer('option-frame-'+st,[0,0,284,320],b);frame.classList.add('frame');
      function border(hover){frame.remove();frame=layer('option-frame-'+(p.eligible&&!selected&&hover?'hover':st),[0,0,284,320],b);frame.classList.add('frame');}
      b.addEventListener('mouseenter',()=>border(true));b.addEventListener('mouseleave',()=>border(false));
      b.addEventListener('click',()=>{const next=ui.toggle(state,p.id);state=next.state;feedback=next.reason;render(p.id);});
    });
    text(`已选择 ${state.selectedIds.length} / ${state.max} 名玩家`,C.countText,26).style.fontWeight='500';
    const hint=text(feedback||ui.hint(state),C.hintText,20,modal,'#827963');hint.setAttribute('role','status');hint.setAttribute('aria-live','polite');
    if(state.allowCancel)button('cancel','取消',C.cancel,()=>finish(ui.cancel(state)));
    button('confirm','确认选择',C.confirm,()=>finish(ui.confirm(state)),!ui.canConfirm(state));
    if(focusId){const target=[...modal.querySelectorAll('[data-player-id]')].find(el=>el.dataset.playerId===focusId);target?.focus({preventScroll:true});}
  }
  function open(){
    state=JSON.parse(JSON.stringify(sample));state.selectedIds=[];feedback='';const type=picker.value;
    if(type==='single'){state.mode='single';state.min=state.max=1;}
    if(type==='exact')state.min=state.max=2;
    if(type==='three')state.players=state.players.slice(0,3);
    if(type==='disabled')state.players[3]={...state.players[3],eligible:false,disabledReason:'不能选择自己'};
    if(type==='required')state.allowCancel=false;
    if(type==='empty')state.players=[];
    render();modal.querySelector('.choice:not([aria-disabled=true])')?.focus({preventScroll:true});result.textContent='点击玩家选项可体验选择；确认后仅输出玩家 ID。';
  }
  document.addEventListener('keydown',e=>{
    if(!opened)return;
    if(e.key==='Escape'){e.preventDefault();finish(ui.cancel(state,'escape'));}
    if(e.key==='Tab'){
      const all=[...modal.querySelectorAll('button:not([disabled])')];if(!all.length)return;
      const first=all[0],last=all.at(-1);
      if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}
      else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
    }
  });
  new ResizeObserver(()=>stage.style.transform=`scale(${viewport.clientWidth/1920})`).observe(viewport);
  picker.addEventListener('change',open);document.getElementById('reopen').addEventListener('click',open);open();
})();
