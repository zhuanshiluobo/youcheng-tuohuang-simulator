/* CardViewer v3.6.1. Dependency-free classic script; works from file://.
   All image permissions and rules remain the responsibility of the caller. */
(function (global) {
  'use strict';
  let nextId = 1;
  const effectLabels = { plot: '计谋', strategy: '策略' };
  const allowedSources = ['quick-action', 'facility', 'covered-area', 'hand', 'discard-area', 'other'];
  function element(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text != null) node.textContent = text;
    return node;
  }
  function validate(input) {
    if (!input || !['inspect', 'use-character'].includes(input.mode)) throw new TypeError('mode must be inspect or use-character');
    if (!allowedSources.includes(input.source)) throw new TypeError('Unknown card viewer source');
    const c = input.card;
    if (!c || typeof c.id !== 'string' || !c.id || typeof c.displayImage !== 'string' || !c.displayImage) throw new TypeError('card.id and card.displayImage are required');
    if (!['character', 'facility', 'other'].includes(c.type)) throw new TypeError('Unknown card type');
    if (input.mode === 'use-character') {
      if (input.source !== 'quick-action' || c.type !== 'character') throw new TypeError('use-character requires a character and quick-action source');
      for (const key of ['plot', 'strategy']) {
        const state = input.effects && input.effects[key];
        if (!state || typeof state.enabled !== 'boolean') throw new TypeError('Explicit effect availability is required');
        if (!state.enabled && (typeof state.disabledReason !== 'string' || !state.disabledReason.trim())) throw new TypeError('Disabled effects require a reason');
      }
    } else if (input.effects !== undefined) throw new TypeError('inspect does not accept effect actions');
  }
  class CardViewer {
    constructor(options = {}) {
      this.options = options;
      this.host = options.host || document.body;
      this.assetBase = (options.assetBase || 'assets').replace(/\/$/, '');
      this.id = 'card-viewer-' + nextId++;
      this.isOpen = false;
      this.input = null;
      this.version = 0;
      this.el = element('div', 'card-viewer');
      this.el.hidden = true;
      this.el.dataset.component = 'card-viewer';
      if (this.host === document.body) this.el.style.position = 'fixed';
      this.canvas = element('div', 'card-viewer__canvas');
      this.dialog = element('section', 'card-viewer__window');
      this.dialog.setAttribute('role', 'dialog');
      this.dialog.setAttribute('aria-modal', 'true');
      this.dialog.setAttribute('aria-labelledby', this.id + '-title');
      this.dialog.setAttribute('aria-describedby', this.id + '-hint');
      this.dialog.tabIndex = -1;
      const bg = element('img', 'card-viewer__background');
      bg.src = this.assetBase + '/window.png'; bg.alt = ''; bg.draggable = false;
      this.title = element('h2', 'card-viewer__title'); this.title.id = this.id + '-title';
      this.card = element('div', 'card-viewer__card');
      this.region = element('div', 'card-viewer__image-region');
      this.card.append(this.region);
      this.actions = element('div', 'card-viewer__actions');
      this.buttons = {};
      for (const key of ['plot', 'strategy', 'cancel']) {
        const button = element('button', 'card-viewer__button');
        button.type = 'button';
        if (key === 'cancel') button.dataset.action = key; else button.dataset.effect = key;
        for (const state of ['normal', 'hover', 'pressed', 'disabled']) {
          const art = element('img', 'card-viewer__button-art');
          art.dataset.state = state;
          art.src = this.assetBase + '/buttons/' + (key === 'cancel' ? 'cancel' : 'action') + '-' + state + '@2x.png';
          art.alt = ''; art.draggable = false;
          button.append(art);
        }
        button.append(element('span', 'card-viewer__button-label', effectLabels[key] || '取消'));
        button.addEventListener('click', event => {
          event.preventDefault(); event.stopPropagation();
          if (key === 'cancel') this.close('cancel'); else this.requestEffect(key);
        });
        this.buttons[key] = button; this.actions.append(button);
      }
      this.hint = element('p', 'card-viewer__hint'); this.hint.id = this.id + '-hint';
      this.hint.setAttribute('aria-live', 'polite');
      this.dialog.append(bg, this.title, this.card, this.actions, this.hint);
      this.canvas.append(this.dialog); this.el.append(this.canvas); this.host.append(this.el);
      this.onKey = this.handleKey.bind(this);
      this.onResize = this.resize.bind(this);
      this.onFocus = event => {
        if (this.isOpen && !this.dialog.contains(event.target)) {
          (this.focusables()[0] || this.dialog).focus({ preventScroll: true });
        }
      };
      this.el.addEventListener('click', event => {
        event.stopPropagation();
        if (!this.dialog.contains(event.target)) this.close('outside');
      });
      this.el.addEventListener('pointerdown', event => event.stopPropagation());
      this.el.addEventListener('pointerup', event => event.stopPropagation());
      this.el.addEventListener('keydown', this.onKey);
      global.addEventListener('resize', this.onResize);
      document.addEventListener('focusin', this.onFocus);
      if (global.ResizeObserver) {
        this.observer = new ResizeObserver(this.onResize);
        this.observer.observe(this.host);
      }
    }
    open(input, trigger) {
      validate(input);
      this.version += 1;
      const version = this.version;
      this.input = input;
      this.previousFocus = trigger || (this.isOpen ? this.previousFocus : document.activeElement);
      this.isOpen = true;
      this.el.hidden = false;
      this.el.dataset.mode = input.mode;
      this.el.dataset.source = input.source;
      this.title.textContent = input.mode === 'use-character' ? '使用角色牌' : '卡牌详情';
      this.actions.hidden = input.mode !== 'use-character';
      this.region.replaceChildren();
      this.region.style.width = '0px'; this.region.style.height = '0px';
      for (const stale of this.card.querySelectorAll('.card-viewer__image-error')) stale.remove();
      if (input.mode === 'use-character') {
        const reasons = [];
        for (const key of ['plot', 'strategy']) {
          const state = input.effects[key];
          this.buttons[key].disabled = !state.enabled;
          this.buttons[key].title = state.enabled ? '' : state.disabledReason;
          this.buttons[key].setAttribute('aria-describedby', this.hint.id);
          if (!state.enabled) reasons.push(effectLabels[key] + '不可用：' + state.disabledReason);
        }
        this.hint.textContent = reasons.length ? reasons.join('　｜　') : '';
      } else this.hint.textContent = '点击窗口外空白处或按 Esc 返回';
      const img = element('img', 'card-viewer__image');
      img.alt = input.card.altText || input.card.name || '卡牌'; img.draggable = false;
      img.onload = () => {
        if (version !== this.version || !this.isOpen) return;
        let crop = this.options.resolveImageRegion ? this.options.resolveImageRegion(input.card) : null;
        if (!crop) crop = { x: 0, y: 0, width: img.naturalWidth, height: img.naturalHeight };
        const { x, y, width, height } = crop;
        if (![x, y, width, height].every(Number.isFinite) || width <= 0 || height <= 0 || x < 0 || y < 0 || x + width > img.naturalWidth || y + height > img.naturalHeight) {
          img.onerror(); return;
        }
        const scale = Math.min(520 / width, 558 / height);
        this.region.style.width = width * scale + 'px'; this.region.style.height = height * scale + 'px';
        img.style.width = img.naturalWidth * scale + 'px'; img.style.height = img.naturalHeight * scale + 'px';
        img.style.left = -x * scale + 'px'; img.style.top = -y * scale + 'px';
      };
      img.onerror = () => {
        if (version !== this.version || !this.isOpen) return;
        this.region.replaceChildren();
        this.card.append(element('p', 'card-viewer__image-error', '卡牌图片未能载入'));
      };
      this.region.append(img);
      // Only the already authorized displayImage is requested. No inferred front/back URL.
      img.src = input.card.displayImage;
      this.resize();
      const first = input.mode === 'use-character' ? this.focusables()[0] : this.dialog;
      first.focus({ preventScroll: true });
      return this;
    }
    resize() {
      const rect = this.el.getBoundingClientRect();
      this.canvas.style.setProperty('--card-viewer-scale', Math.min(rect.width / 1920, rect.height / 1080));
    }
    focusables() { return [...this.actions.querySelectorAll('button:not(:disabled)')].filter(el => !this.actions.hidden && !el.hidden); }
    handleKey(event) {
      if (!this.isOpen) return;
      if (event.key === 'Escape') {
        event.preventDefault(); event.stopPropagation(); this.close('back');
      } else if (event.key === 'Tab') {
        const buttons = this.focusables();
        if (!buttons.length) { event.preventDefault(); this.dialog.focus(); return; }
        const current = buttons.indexOf(document.activeElement);
        if (event.shiftKey && current <= 0) { event.preventDefault(); buttons[buttons.length - 1].focus(); }
        else if (!event.shiftKey && (current < 0 || current === buttons.length - 1)) { event.preventDefault(); buttons[0].focus(); }
      }
    }
    hide() {
      if (!this.isOpen) return;
      this.isOpen = false;
      this.version += 1;
      this.el.hidden = true;
      if (this.previousFocus && this.previousFocus.isConnected && typeof this.previousFocus.focus === 'function') this.previousFocus.focus({ preventScroll: true });
    }
    close(reason = 'back') {
      if (!['cancel', 'back', 'outside'].includes(reason)) throw new TypeError('Unknown close reason');
      if (!this.isOpen) return;
      this.hide();
      const payload = { reason };
      this.el.dispatchEvent(new CustomEvent('cardviewer:close', { bubbles: true, detail: payload }));
      if (typeof this.options.onClose === 'function') this.options.onClose(payload);
    }
    requestEffect(effect) {
      if (!this.isOpen || !this.input || this.input.mode !== 'use-character') return;
      if (!['plot', 'strategy'].includes(effect) || !this.input.effects[effect].enabled) return;
      const payload = { cardId: this.input.card.id, effect };
      this.hide(); // Hide before handing off, preventing a duplicate click in this viewer.
      this.el.dispatchEvent(new CustomEvent('cardviewer:request-effect', { bubbles: true, detail: payload }));
      if (typeof this.options.onRequestEffect === 'function') this.options.onRequestEffect(payload);
    }
    destroy() {
      this.hide();
      global.removeEventListener('resize', this.onResize);
      document.removeEventListener('focusin', this.onFocus);
      if (this.observer) this.observer.disconnect();
      this.el.remove();
    }
  }
  global.CardViewer = CardViewer;
})(window);
