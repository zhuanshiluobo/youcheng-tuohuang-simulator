// Native vector UI buttons; SVG masters are the source for both PNG densities.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const out=path.join(root,'assets/buttons');fs.mkdirSync(out,{recursive:true});
const palettes={
 action:{normal:['#D6CEBD','#C8BEA9','#514737','#EEE6D5','#AA8E50','#302B23'],hover:['#E5DDCC','#D7CAB0','#B29860','#FAF1DC','#B19248','#29251E'],pressed:['#BEB096','#C9BDA4','#8D7546','#E2D2B4','#8D713D','#29251E'],disabled:['#736B5D','#686052','#817461','#A79B83','#81735A','#B9AF99']},
 cancel:{normal:['#4F473C','#40392F','#8E7C62','#B7A68A','#867252','#D8CBB5'],hover:['#625647','#4B4135','#B4A07E','#D1BFA0','#A78C5F','#F0E3CB'],pressed:['#3D342A','#4B4033','#A08A65','#BBA180','#8D754A','#DFD0B5'],disabled:['#423C34','#3A342D','#675B48','#82735B','#675B48','#8F8270']}
};
const manifest={version:'3.6.1',units:'logical px',textBaked:false,assets:{}};
for(const [kind,states] of Object.entries(palettes))for(const [state,c] of Object.entries(states)){
 const w=kind==='action'?224:176,h=64,id=kind+'-'+state;
 let fibres='';for(let i=0;i<11;i++){const x=14+i*17; if(x>w-14)break;const y=12+(i*13)%34;fibres+=`<path d="M${x} ${y}l9 -1" stroke="${c[2]}" opacity=".045" stroke-width=".65"/>`;}
 const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}"><defs><linearGradient id="fill" x2="0" y2="1"><stop stop-color="${c[0]}"/><stop offset="1" stop-color="${c[1]}"/></linearGradient></defs><rect x=".75" y=".75" width="${w-1.5}" height="${h-1.5}" rx="5" fill="url(#fill)" stroke="${c[2]}" stroke-width="1.25"/><rect x="3.5" y="3.5" width="${w-7}" height="${h-7}" rx="3" fill="none" stroke="${c[3]}" stroke-width=".65" opacity="${kind==='action'?'.7':'.25'}"/>${fibres}${state!=='disabled'?`<path d="M${kind==='action'?32:24} 57.5H${w-(kind==='action'?32:24)}" stroke="${c[4]}" stroke-width="${kind==='action'?1.7:.8}" opacity="${kind==='action'?'.85':'.38'}"/>`:''}</svg>`;
 const file=path.join(out,id+'.svg');fs.writeFileSync(file,svg);
 for(const density of [1,2])execFileSync('inkscape',[file,'--export-type=png',`--export-width=${w*density}`,`--export-height=${h*density}`,'--export-filename='+path.join(out,id+(density===2?'@2x':'')+'.png')],{stdio:'pipe'});
 manifest.assets[id]={svg:`assets/buttons/${id}.svg`,png:`assets/buttons/${id}.png`,png2x:`assets/buttons/${id}@2x.png`,logicalSize:[w,h],sourceSize1x:[w,h],sourceSize2x:[w*2,h*2],sourceSlices1x:[12,12,12,12],sourceSlices2x:[24,24,24,24],targetSlices:[12,12,12,12],labelColor:c[5],labelOffsetY:state==='pressed'?1:0};
}
fs.writeFileSync(path.join(root,'assets/button-manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log('8 SVG masters + 16 PNG textures');
