// Compose existing UI textures and original card artwork; no artwork is redrawn.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const L=JSON.parse(fs.readFileSync(path.join(root,'layout.json'),'utf8'));
const uri=(p)=>`data:image/${p.endsWith('.jpg')?'jpeg':'png'};base64,${fs.readFileSync(path.join(root,p)).toString('base64')}`;
const image=(u,x,y,w,h)=>`<image xlink:href="${u}" x="${x}" y="${y}" width="${w}" height="${h}" preserveAspectRatio="none"/>`;
const text=(x,y,t,size=28,color='#EFE4D6',weight=400)=>`<text x="${x}" y="${y}" text-anchor="middle" dominant-baseline="central" font-family="Noto Sans CJK SC, Microsoft YaHei UI, sans-serif" font-size="${size}" font-weight="${weight}" fill="${color}">${t}</text>`;
function button(id,label,primary){
 const [x,y,w,h]=L.regions[id];
 return image(uri('assets/buttons/'+(primary?'action':'cancel')+'-normal@2x.png'),x,y,w,h)+text(x+w/2,y+h/2,label,26,primary?'#302B23':'#D8CBB5',700);
}
function card(type){
 const [x,y,w,h]=L.card.sampleDisplayRect;
 const art=type==='facility'?image(uri('preview/originals/facility.jpg'),x,y,w,h):type==='covered'?image(uri('preview/originals/character-back.jpg'),x,y,w,h):`<clipPath id="card-crop"><rect x="${x}" y="${y}" width="${w}" height="${h}"/></clipPath><g clip-path="url(#card-crop)">${image(uri('preview/originals/character-atlas.jpg'),x-1800*w/600,y,2400*w/600,1700*h/850)}</g>`;
 return `<rect x="${x+3}" y="${y+5}" width="${w}" height="${h}" fill="#080705" opacity=".45"/>${art}`;
}
function render(mode,type='character'){
 const active=mode==='use';
 return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1920" height="1080" viewBox="0 0 1920 1080"><defs><radialGradient id="shade"><stop stop-color="#39332C"/><stop offset="1" stop-color="#171513"/></radialGradient></defs><rect width="1920" height="1080" fill="url(#shade)"/><g transform="translate(73 96.5)">${image(uri('assets/window.png'),0,0,1774,887)}${text(887,84,active?'使用角色牌':'卡牌详情',40,'#EFE4D6',700)}${card(type)}${active?button('plot','计谋',true)+button('strategy','策略',true)+button('cancel','取消',false):''}${text(887,active?720:780,active?'':'点击窗口外空白处或按 Esc 返回',18,'#C9B8A6')}</g></svg>`;
}
fs.mkdirSync(path.join(root,'preview'),{recursive:true});
for(const [name,mode,type] of [['use-character','use','character'],['inspect-character','inspect','character'],['inspect-facility','inspect','facility'],['inspect-covered','inspect','covered']]){
 if(process.argv.includes('--use-only') && mode!=='use') continue;
 const svg=path.join(root,'preview',name+'.svg'),png=path.join(root,'preview',name+'.png');
 fs.writeFileSync(svg,render(mode,type));
 execFileSync('inkscape',[svg,'--export-type=png','--export-filename='+png],{stdio:'pipe'});
 console.log(name+'.png');
}
