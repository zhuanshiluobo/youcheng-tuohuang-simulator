import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {execFileSync} from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const manifest=JSON.parse(fs.readFileSync(path.join(root,'assets/button-manifest.json')));
const t=(x,y,s,size=22,color='#E8DECA',anchor='start',weight=400)=>`<text x="${x}" y="${y}" font-family="Noto Sans CJK SC, Microsoft YaHei UI, sans-serif" font-size="${size}" font-weight="${weight}" fill="${color}" text-anchor="${anchor}" dominant-baseline="central">${s}</text>`;
let body=`<rect width="1280" height="660" fill="#352E26"/>${t(64,52,'卡牌查看 · 新版按钮',30)}${t(64,96,'米灰哑光底 · 完整圆角 · 文字与贴图分离',19,'#BBAF97')}`;
for(const [i,state] of ['normal','hover','pressed','disabled'].entries()){
 const y=146+i*116;
 body+=t(72,y+42,['普通','悬停','按下','不可用'][i],22,'#C7B99F');
 for(const [j,label] of ['计谋','策略','取消'].entries()){
  const a=manifest.assets[(j===2?'cancel':'action')+'-'+state],x=292+[0,248,512][j]*1.3,w=a.logicalSize[0]*1.3,h=64*1.3;
  const u='data:image/png;base64,'+fs.readFileSync(path.join(root,a.png2x)).toString('base64');
  body+=`<image xlink:href="${u}" x="${x}" y="${y}" width="${w}" height="${h}"/>`+t(x+w/2,y+h/2+a.labelOffsetY*1.3,label,26*1.3,a.labelColor,'middle',700);
 }
}
body+=t(64,625,'计谋与策略保持同级，取消独立弱化。图中按钮以 1.3 倍展示。',18,'#BBAF97');
const svg=`<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="1280" height="660" viewBox="0 0 1280 660">${body}</svg>`;
const f=path.join(root,'preview/button-states.svg');fs.writeFileSync(f,svg);execFileSync('inkscape',[f,'--export-type=png','--export-filename='+path.join(root,'preview/button-states.png')],{stdio:'pipe'});
