/** Render-only data adapter. Counts empty slots independently of influence. */
export function buildRegionRows(map, palette, players, snapshot) {
  const known = new Map(palette.regions.map(r => [r.id, r]));
  return map.regionOrder.map(region => {
    const slots = map.regions[region].slots;
    const states = slots.map(s => snapshot.slotStates?.[s.id]);
    const complete = states.every(s => typeof s?.isEmpty === 'boolean');
    const values = players.map(p => {
      const v = snapshot.influenceByRegion?.[region]?.[p.id];
      return {playerId:p.id, marker:p.marker, value:Number.isFinite(v) ? v : null};
    });
    return {region, label:known.get(region).label, points:known.get(region).points,
      regionSquare:`assets/region-squares/region-${region}-64.png`, values,
      emptySlotCount:complete ? states.filter(s=>s.isEmpty).length : null,
      totalSlotCount:slots.length, slotDataComplete:complete};
  });
}
