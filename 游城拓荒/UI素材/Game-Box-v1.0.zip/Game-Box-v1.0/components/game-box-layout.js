(function (root) {
  'use strict';
  const poses = [
    { x: -0.07, y: 0.03, angle: -6 },
    { x: 0.06, y: -0.02, angle: 4 },
    { x: -0.03, y: -0.03, angle: -1 },
    { x: 0.04, y: 0.02, angle: 6 },
    { x: 0, y: 0, angle: -3 }
  ];
  function positive(v, name) {
    if (!Number.isFinite(v) || v <= 0) throw new Error(name + ' must be positive');
    return v;
  }
  function contain(sourceWidth, sourceHeight, maxWidth, maxHeight) {
    [sourceWidth, sourceHeight, maxWidth, maxHeight].forEach((v, i) => positive(v, 'dimension ' + i));
    const s = Math.min(maxWidth / sourceWidth, maxHeight / sourceHeight);
    return { width: sourceWidth * s, height: sourceHeight * s, scale: s };
  }
  function bounds(cards) {
    if (!cards.length) return null;
    let left = Infinity, right = -Infinity, top = Infinity, bottom = -Infinity;
    for (const c of cards) {
      const a = c.angle * Math.PI / 180;
      const rw = Math.abs(c.width * Math.cos(a)) + Math.abs(c.height * Math.sin(a));
      const rh = Math.abs(c.width * Math.sin(a)) + Math.abs(c.height * Math.cos(a));
      left = Math.min(left, c.cx - rw / 2); right = Math.max(right, c.cx + rw / 2);
      top = Math.min(top, c.cy - rh / 2); bottom = Math.max(bottom, c.cy + rh / 2);
    }
    return { left, right, top, bottom, width: right - left, height: bottom - top };
  }
  // Order is bottom-to-top. Input image dimensions must describe ONE visible sprite,
  // not an entire atlas. There is intentionally no default character/event aspect ratio.
  function layoutPile(cards, area, options = {}) {
    positive(area.width, 'area.width'); positive(area.height, 'area.height');
    const padding = Math.max(0, options.padding ?? 10);
    const aw = Math.max(1, area.width - padding * 2), ah = Math.max(1, area.height - padding * 2);
    const maxWidth = options.maxWidth ?? aw, maxHeight = options.maxHeight ?? ah;
    const visible = cards.slice(-5);
    if (!visible.length) return { count: 0, cards: [], bounds: null, status: 'empty' };
    if (visible.some(c => !Number.isFinite(c.sourceWidth) || c.sourceWidth <= 0 || !Number.isFinite(c.sourceHeight) || c.sourceHeight <= 0)) {
      return { count: cards.length, cards: [], bounds: null, status: 'awaiting-image-size' };
    }
    let placed = visible.map((card, i) => {
      const size = contain(card.sourceWidth, card.sourceHeight, maxWidth, maxHeight);
      const p = visible.length === 1 ? {x:0,y:0,angle:0} : poses[5 - visible.length + i];
      return {...card, width:size.width, height:size.height, cx:p.x*size.width, cy:p.y*size.height, angle:p.angle, z:i};
    });
    let b = bounds(placed);
    const scale = Math.min(1, aw / b.width, ah / b.height);
    const midX = (b.left + b.right) / 2, midY = (b.top + b.bottom) / 2;
    placed = placed.map(c => ({...c,
      width:c.width*scale, height:c.height*scale,
      cx:(area.x??0)+area.width/2+(c.cx-midX)*scale,
      cy:(area.y??0)+area.height/2+(c.cy-midY)*scale
    }));
    return {count:cards.length, cards:placed, bounds:bounds(placed), status:'ready'};
  }
  function layoutTokens(items, width, viewportHeight, scrollY = 0) {
    positive(width, 'token width'); positive(viewportHeight, 'token viewport');
    const gap=14, rowHeight=126;
    let x=0,y=0;
    const placed=items.map(item=>{
      positive(item.sourceWidth,'token sourceWidth'); positive(item.sourceHeight,'token sourceHeight');
      const wide=item.sourceWidth/item.sourceHeight>2.5;
      const desired=wide?228:168;
      const cellWidth=Math.min(desired,width);
      if(x>0 && x+cellWidth>width){x=0;y+=rowHeight+gap;}
      const maxImageWidth=Math.max(1,cellWidth-58),maxImageHeight=100;
      const size=contain(item.sourceWidth,item.sourceHeight,maxImageWidth,maxImageHeight);
      const result={...item,x,y,width:cellWidth,height:rowHeight,
        imageX:x+(maxImageWidth-size.width)/2,imageY:y+(rowHeight-size.height)/2,
        imageWidth:size.width,imageHeight:size.height,countX:x+cellWidth-39,countY:y+rowHeight/2};
      x+=cellWidth+gap;return result;
    });
    const contentHeight=items.length?y+rowHeight:0;
    const maxScroll=Math.max(0,contentHeight-viewportHeight);
    const offset=Math.max(0,Math.min(scrollY,maxScroll));
    const thumbHeight=maxScroll ? Math.min(viewportHeight,Math.max(Math.min(36,viewportHeight),viewportHeight*viewportHeight/contentHeight)) : viewportHeight;
    return {items:placed.map(i=>({...i,screenY:i.y-offset,imageScreenY:i.imageY-offset,countScreenY:i.countY-offset})),
      contentHeight,viewportHeight,scrollY:offset,maxScroll,showScrollbar:maxScroll>0,
      thumbHeight,thumbY:maxScroll ? offset/maxScroll*(viewportHeight-thumbHeight):0};
  }
  function ownEnterprise(board,currentPlayerId) {
    if (!board) return null;
    if (board.ownerPlayerId !== currentPlayerId) return null;
    return board;
  }
  function inspectPile(kind,cards) {
    if (!['character','event'].includes(kind)) throw new Error('Unsupported pile kind');
    return {mode:'inspect',source:'game-box',kind,cards:cards.map(c=>({id:c.id,displayImage:c.displayImage,face:c.face,sourceWidth:c.sourceWidth,sourceHeight:c.sourceHeight}))};
  }
  root.GameBoxLayout={contain,bounds,layoutPile,layoutTokens,ownEnterprise,inspectPile};
  if(typeof module!=='undefined' && module.exports) module.exports=root.GameBoxLayout;
})(typeof globalThis!=='undefined'?globalThis:this);
