# 克隆与活动展示优化的稳定Unity复验

2026-10-23。70两路均整轮结束且停止写入。008 CONFIRM-HOTPATH-R5核1055次SHA和完整结果对照；017 ACTIVE-PRESENTATION-REUSE-R11核3101次，其中3100相符，1项身份文件自哈希无效已定位为先创建空文件再枚举自身，独立外部封存的完整身份SHA相符，不是源/DLL漂移。源码各自核证后汇合。本轮仅 QY-017 是源码补正、Unity编译和运行作者；QY-018按71只读核另一项旧秘密退役可见性冲突，不改任何源码，不阻塞本轮独立验证。019仍停止。

先读根AGENTS、01、08、70、71，以及两家最终报告、协调复核-QY008-CONFIRM-HOTPATH-R5.json、协调复核-QY017-ACTIVE-PRESENTATION-REUSE-R11.json。按以下明确范围开始，不待另一次空派发。

## 固定输入与证据补正

- 008生产仅 GameStateCloneService.cs 延迟创建成功路径的诊断字符串，SHA8555c3411c97d593bb022437c51aaa2598cafa7bca3594ef18ec593f8ac26203；新增QY008CloneDiagnosticPathR5Tests两方法及meta。不减少必要clone/copy/事务、不改字段/拒绝语义。008 R4前增量保持。
- 017 R11为5生产、3测试、3meta，ActiveContentCatalogBuilder SHA c8757489bb097bf7503da1e222d7fb82cbc7203d16a816ae92d1a8faefd96274；其余逐最终源码与控制.json核。只读展示必须复用已装配pack，当前session/配置/内容核对与实际候选权限分别检查，无消费端fallback重复装配。
- 007复合动力Lua SHA da49f8ed18cfd62e57bdec34df799d720c48351e813d6657cde402d6e69b434e 和R10全部内容保持。SourceFacts1.6、5/5/4/2/6及局部1不形式升级。
- R11 CLR合同-a007/运行身份.json 的 outputs错误包含自己刚创建时空文件SHA e3b0...；实际文件SHA201b9ef58cc835ff46983c10ba3ab98ec4828cf61621ba77b03a7790a2087889与外部历史清单一致。请在本轮新增证据勘误说明，后续生成器先收集排除自己再写身份，再由外层清单哈希；保留R11原件，不覆盖/重写历史结果，不把这项不合法自哈希写成已匹配。
- 本轮输出目录：实施记录/QY-017-PERFORMANCE-INTEGRATION-R12，以及对应本人Logs目录。只按明确允许路径核文件/差异，禁止无路径git status或枚举受限UI原档案。
- 核所有正在运行Unity是否属于用户，不能强关/删锁代替占用检查。使用隐藏编译/隔离进程，正常退出，保持原场景/Prefab，不运行Rebuild/生成器。

## 一次稳定编译和有限保护

完整稳定编译后保实际输入、DLL SHA/MVID、加载来源和内容身份。不用008的SDK或R11冻结DLL塞进Unity。当前只有本家可进行必要机械夹具/编译补正；若发现真实通用语义或Lua问题，保首次现场、明确责任与最小修复范围，独立组继续，不擅改规则/断言掩盖。

优先3个有清晰目的的Unity批次，能在同进程隔离的样本合批；不是硬性必须3次，若失败应保首次并修必要问题后只重受影响组，避免每小例都启动Unity：

1. 功能批：008的017规则最小过滤器.txt名义12例，R11 ActivePresentationCatalogTests四方法与ActivePresentationUiTests三参数共7例，再加原 FormalChoicePagesMeasureOriginalSelectionAndConfirmation("preview") 一个参数。名义20例，实际发现去重为准。不要使用整个StatePerformanceContractTests类过滤器把71待定的查询断言混入，也不要宣称整个类通过。
2. 确认性能批：008的017确认性能过滤器.txt，原A08无监听/有监听各3样本共6例，face无监听/有监听各1例，共8参数。按场景清理singleton、UI与监听，保全部值。只谈本批实际冷/热边界，不把后续样本当独立资产冷开。
3. 真正首次详情批：原 FormalChoicePagesMeasureOriginalSelectionAndConfirmation("ability") 无额外CPU监听1例，用新进程保原首详情与同局第二次打开、返回草稿、确认一次、后继可交互。不得先开企业页、预加载其图像/预执行详情。U02若只是功能已在第1批，不另开进程取多余冷样本。

基础名义共29参数，所有发现与原始XML逐项记；零发现是错误。新网络入口两例只证明装配，原正常网络/多局未覆盖仍写明。无需重跑38/95/159/549历史全量；确有新增影响才追加具体既有保护并说明原因。R10复合动力、多萝西、保罗不因它们曾失败就重复全套。

## 实际页面与测量

- 新A08在原合法隔离准备完成、按钮正式提交前封存真实Host与原命令参数，标R12新现场，不能倒填R10没有的前Host。保2真实token一次移转和实际正文effect.influence.place.target后继。
- face保当前GameId/真实请求、选项、当前玩家到下一玩家的正式round.entrepreneur.choose后继，以及旧按钮/旧答案拒绝。
- Submit分段沿既有计时只在目标同步线程安装监听，finally恢复。前/后Host导出、JSON和文件I/O均在计时外。回合面ExecutionTimings含准备命令，必须用目标确认的差值或独立原段；不把累计clone/copy当单次成本。
- 无监听与有监听分别汇报；嵌套段不相加，Unity分配计数不可用写不可用，不能套CLR分配节省或把.NET9与Unity时间相减。
- 详情计完整bootstrap_total、active_catalog、presentation_bind以及原按钮至布局、首次/重复详情。计新增展示出口创建成本，不宣称把成本搬到启动就是降低总成本。R10没有相同bootstrap总段，不虚构启动A/B改善；本轮确认详情重复active构建为0、正常装配为1并测实际首开。
- 原R10无监听A08整体848.924—909.795ms，face956.18/1015.40ms，首详情842.564ms其中重复snapshot633.878ms，仅作为原身份样本参考。保候选内容/数量随机差异、所有样本和失败，不挑最好值。
- 若仍有明确热点，只在实际证据支持下给最小后续范围。普通本家性能修正可直接做，跨职责实质机制改动返回协调；不因还有优化空间任意扩大本轮。没有新稳定时延前不宣称已解决卡顿。

## 结束条件

交限定差异及前后身份、完整运行发现/执行/去重/失败、原始XML与证据清单、无监听和监听全部样本及对照、实际功能和性能结论、剩余具体问题。本轮暂不新建Player包或正常局；先交稳定结果，由协调据卡顿余量和71结论决定后续。不覆盖首次失败，不清旧证据，不恢复019，不要求用户重复确认普通技术工作。

完成后停止写入。协调仅在整轮结束后读取最终交付，持续wait并保存afterCursor。现在开始。

