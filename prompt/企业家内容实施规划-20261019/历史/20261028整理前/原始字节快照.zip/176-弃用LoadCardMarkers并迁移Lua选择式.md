# 弃用LoadCardMarkers并迁移Lua选择式

> 当前规则已由179及用户2026-10-26直接裁定覆盖：库存由Lua判断、逐枚MoveItem、缺失单枚失败，不新增Choice前供应屏障或整批预留/足额交付。178新增G1/G2实施撤销；下文仅保留历史依据，冲突项不得再执行。

## 用户当前授权与暂停边界

用户2026-10-25明确：「把LoadCardMarkers接口弃用了，全部改成选择式。然后再清理内核中弃用LoadCardMarkers产生的无效代码。」本项是新代码实施授权，非恢复019测试。019和自动续测qy保持暂停；不操作保留Host、旧构建或存档，不启动正常整局，不使用computer-use。根仅修改文档，代码由原用户创建的执行者完成。

## 当前事实与目标

现行生产Lua直接调用共5处：entrepreneurs/agnes.lua:92、entrepreneurs/tiago.lua:273、characters/infected.character.lin.tactic.lua:37、characters/operator.dorothy.tactic.lua:104、characters/operator.passenger.tactic.lua:2。行号只定位，实施先读当前文件。

LoadCardMarkers本身生成effect.quantity.choose及player_marker行；其内核CardMarkerFlow/FixedMarkerDelivery还与条件式足额交付、资源付款、保存和版本指纹耦合。本次必须实际去除正式API和失去用途的执行路径，不能只隐藏数量页、改名包装或把原API改成内部专用实现。

四处可选数量改由Lua既有Effect.Choice（既定选择式）列出合法数量/不获得分支，选中后用现有Effect.MoveItem通用token转移移动真实实例。数量上限、真实库存、载体、原主、不可复用、本人权限、真实副作用和后续时序不变；无库存时按原规则跳过不弹空页。选项及提示用外部Text.Ref，文字写清指令/声望或实际标记动作，不能让C#猜卡名/区域名/用途。

艾格尼丝原已有gainCommand数量选择，最终LoadCardMarkers为fixed交付。保留既有选择式和条件式入口，固定分支改真实MoveItem，不增加二次数量选择或可任意少拿的规则。额外关注购买指令足额条件、真实库存不足不得先收费、所有不付款获得指令的分支、完整动态数量（不随意截断）、选定实例的归属与后续响应。不得为迁移新增企业家专属C#接口/规则分支。

## 分工与写集

1. QY-013 AGNES-LOAD-MARKERS-CHOICE-MIGRATION-R12：只写agnes.lua、本人确有必要的能力/处理器声明及A.zh-CN.json新引用；独立新增本轮有限用例/证据。不得写全局pack版本、共享core文本、生产C#、其它卡Lua、共享测试fixture。对fixedDeliveryRequirement/deliveryRef撤除给出替代的现有通用机制及不足的具体证据，不能删除足额语义冒完成。
2. QY-014 TIAGO-LOAD-MARKERS-CHOICE-MIGRATION-R10：只写tiago.lua、本人必要能力/处理器声明及D.zh-CN.json新引用；独立新增有限用例/证据。基金投资掷骰完成后可选获得0至上限声望，真实标记转移成功后进入骰点选择；保3A不同点筛选/全相同不挂额外条件及其余已核修复。不得写pack、共享文本、C#或其他卡。
3. QY-009 CHARACTER-LOAD-MARKERS-CHOICE-MIGRATION-R6：只写上述林、多萝西、异客3Lua及它们必要能力/处理器声明；共享texts.zh-CN.json只增加/修改这3张卡的必要新提示选项键，不覆盖用户其他文本，不整理全文件。新增独立有限用例/证据；不得写pack/C#/其他Lua/共享测试fixture。保林上限2、多萝西4、异客5及原收尾/标记生命周期规则。
4. QY-005 LOAD-MARKERS-RETIREMENT-READONLY-R15：本轮只读梳理全部内核、Lua绑定/编译器、查询、持久化、恢复、版本指纹、UI消费者与测试依赖，输出后继精确删除/改写清单及共享接口缺口；仅写独立证据/方案，不改代码或原文。等待前三项completed由根核后另行授权实际清理。现有MoveItem仍被其他token/卡牌使用，不能误删通用真实转移/载体规则。

后三项文字或声明可能共享文件：各自只改自己条目，若发现其他任务同时写同一文件，先报告根收敛为一名合并写入者。全局pack版本/清单和编译汇合在005后续阶段一次处理；四个执行者本阶段均不启动Unity、Build或正常程序，避免争用。有限纯Lua语法/业务/合同检查可以做，必须标隔离，不能算正常UI验收。

## 内核清理后继标准（本轮005先分析，后续根再派实际写）

- 不仅移除5条调用，还需清理公开LoadCardMarkers绑定、effect.card.load_markers的注册/执行/校验/续接、仅服务此接口的CardMarkerFlow和FixedMarkerDelivery专用状态/付款钩子/查询/指纹、失去引用的数量行生成分支及相关死测试。先证实用途；仍有有效通用消费者的代码保留并列明理由，不以类名直接整类删除。
- 禁止留只改名字的替身API，禁止把数字选项、卡名或企业家规则挪进C#。已有通用Condition/Choice/MoveItem的安全性保持；若真实通用能力不足，列最小缺口和消费者后由根给唯一写者实施，不乱补专属接口。
- 旧保存/冻结2.0.2/历史效果节点分开处置。可以保必要的有限历史识别/明确拒绝以免误读，但不能保旧执行管线冒已清理；不得编辑用户存档、改其hash或把旧2.0.2装入不支持LoadCardMarkers的新Runtime冒恢复。原R57恢复包/确认506档保持原样，新内容新版本由后继统一维护。
- 检查新增Choice续接可恢复、0/1/上限、库存不足、实际选项文本、准确数量转移及后继。只跑适当的有限检查，不重跑无关矩阵，不因用户文本保存冻结/回退。
- 真正无用文件删除前列每个项目内绝对路径并核验；用户授权本次弃用死代码清理，不扩大到日志/构建/存档/无关文件。git状态用明确范围，不触受限原UI档案。

## 交付与协调

交付实际最小patch、改动前后SHA、调用/依赖扫描、检查原件及未运行项、语义保留映射、共享文件/新接口阻塞。不改019/017待办夹具。完整本家提示词与本文件一并派发，根只在整轮completed后查看最终及证据；运行中不发逐条补丁反馈。用户新说明优先，未经明确恢复019绝不续测。
