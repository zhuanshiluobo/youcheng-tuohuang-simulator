namespace YC.Domain.Cards
{
    public enum CharacterCardEffectKind
    {
        Unsupported,
        CannotTradeChannel,
        CannotRequisition,
        LiskarmSecurityProtocol,
        LiskarmControlPosition,
        ElysiumLogistics,
        ElysiumNavigation,
        TexasSpecialDelivery,
        TexasRemoveAndDoubleMove,
        TinManEstablishPrestige,
        TinManDeepPlanning,
        External
    }

    public sealed class CharacterCardDefinition
    {
        public string CardId = string.Empty;
        public string TemplateId = string.Empty;
        public string Name = string.Empty;
        public bool IsExternalDefinition;
        public string ConfiguredStrategyAbilityId = string.Empty;
        public string ConfiguredTacticAbilityId = string.Empty;
        public CharacterCardEffectKind StrategyEffect;
        public CharacterCardEffectKind TacticEffect;

        // 能力 ID 是数据目录的稳定脚本路由，不是角色卡实例 ID 的 C# 分支。
        public string StrategyAbilityId
        {
            get { return string.IsNullOrEmpty(ConfiguredStrategyAbilityId) ? CreateAbilityId(TemplateId, CharacterEffectModes.Strategy) : ConfiguredStrategyAbilityId; }
        }

        public string TacticAbilityId
        {
            get { return string.IsNullOrEmpty(ConfiguredTacticAbilityId) ? CreateAbilityId(TemplateId, CharacterEffectModes.Tactic) : ConfiguredTacticAbilityId; }
        }

        private static string CreateAbilityId(string templateId, string mode)
        {
            return string.IsNullOrEmpty(templateId) || string.IsNullOrEmpty(mode)
                ? string.Empty
                : "character." + templateId + "." + mode;
        }
    }

    public static class CharacterEffectModes
    {
        public const string Strategy = "strategy";
        public const string Tactic = "tactic";
        public const string Both = "both";
    }

    public static class CharacterEffectOrders
    {
        public const string StrategyFirst = "strategy-first";
        public const string TacticFirst = "tactic-first";
    }

    public static class CharacterEffectParameterKeys
    {
        public const string ResourceType = "resourceType";
        public const string FacilityCardId = "facilityCardId";
        public const string Choice = "choice";
        public const string SourceInfluenceSlotId = "sourceInfluenceSlotId";
        public const string TargetInfluenceSlotId = "targetInfluenceSlotId";
        public const string PlacementSlotId1 = "placementSlotId1";
        public const string PlacementSlotId2 = "placementSlotId2";
        public const string TargetLocationId = "targetLocationId";
        public const string RemovalTargetInfluenceSlotId = "removalTargetInfluenceSlotId";
        public const string MoveSourceSlotId1 = "moveSourceSlotId1";
        public const string MoveTargetSlotId1 = "moveTargetSlotId1";
        public const string MoveSourceSlotId2 = "moveSourceSlotId2";
        public const string MoveTargetSlotId2 = "moveTargetSlotId2";
        public const string TinManPurchasePureOriginium12 = "tinMan.purchasePureOriginium12";
        public const string TinManPurchasePureOriginium15 = "tinMan.purchasePureOriginium15";
        public const string SaleOriginium = "sale.originium";
        public const string SaleOriginiumShard = "sale.originium-shard";
        public const string SaleIron = "sale.iron";
        public const string SalePureOriginium = "sale.pure-originium";
        public const string OfferSecondEffect = "character.offer-second-effect";
        public const string PendingCharacterEffectSourceCommandId = "character.pending-source-command-id";
    }

    public static class CharacterEffectChoiceIds
    {
        public const string GainGold = "gain-gold";
        public const string MoveInfluence = "move-influence";
        public const string TinManPurchaseFirstPureOriginium = "tin-man-purchase-first-pure-originium";
        public const string TinManPurchaseSecondPureOriginium = "tin-man-purchase-second-pure-originium";
        public const string TinManFinishPurchasing = "tin-man-finish-purchasing";
        public const string ContinueSecondEffect = "continue-second-effect";
        public const string FinishCharacterUse = "finish-character-use";
    }

    public static class CharacterPendingChoiceTypes
    {
        public const string TinManDiscard = "character.tin-man.discard";
        public const string TinManFirstPurchase = "character.tin-man.first-purchase";
        public const string TinManSecondPurchase = "character.tin-man.second-purchase";
        public const string LiskarmCleanupRemoval = "character.liskarm.cleanup-removal";
        public const string SecondEffectDecision = "character.second-effect.decision";
        public const string SecondEffectExecution = "character.second-effect.execution";
    }
}
