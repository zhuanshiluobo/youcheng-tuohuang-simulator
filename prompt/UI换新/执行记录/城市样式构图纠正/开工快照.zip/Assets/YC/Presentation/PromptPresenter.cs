using UnityEngine;
using UnityEngine.UI;

namespace YC.Presentation
{
    internal sealed class PromptPresenter
    {
        private const float VisibleSeconds = 3f;
        private const float FadeSeconds = 0.16f;
        private const float SlideSpeed = 2200f;

        private readonly Text promptText;
        private readonly RectTransform panelTransform;
        private readonly CanvasGroup promptCanvasGroup;
        private readonly UiPromptSizeInput promptLayout;
        private float hideAt;
        private float targetX;
        private float targetAlpha;
        private bool hideScheduled;

        private PromptPresenter(GameplayPromptView view)
        {
            Canvas = view.Canvas;
            promptText = view.PromptText;
            panelTransform = view.PanelTransform;
            promptCanvasGroup = view.CanvasGroup;
            promptLayout = view.PromptLayout;
            targetX = GetHiddenX();
            targetAlpha = 0f;
        }

        public Canvas Canvas { get; private set; }

        public static PromptPresenter Bind(GameplayPromptView view)
        {
            var reason = string.Empty;
            if (view == null || !view.TryValidateConfiguration(out reason))
            {
                Debug.LogError("[PromptPresenter] 无法绑定交互提示 View：" +
                               (view == null ? "引用为空。" : reason));
                return null;
            }

            return new PromptPresenter(view);
        }

        public void SetPrompt(string message, string pendingPrompt = null)
        {
            if (!string.IsNullOrEmpty(pendingPrompt) && (string.IsNullOrEmpty(message) || !message.Contains(pendingPrompt)))
                message = string.IsNullOrEmpty(message) ? pendingPrompt : message + "\n" + pendingPrompt;
            if (string.IsNullOrWhiteSpace(message))
            {
                Hide();
                return;
            }

            if (promptText != null)
            {
                promptText.text = message;
                promptLayout?.RefreshContent();
            }

            if (promptCanvasGroup != null)
            {
                targetX = GetVisibleX();
                targetAlpha = 1f;
                hideAt = 0f;
                hideScheduled = false;
            }
        }

        public void Update(bool keepVisible)
        {
            if (promptCanvasGroup == null || panelTransform == null)
            {
                return;
            }

            if (Mathf.Approximately(targetX, GetVisibleX()) &&
                hideScheduled &&
                !keepVisible &&
                Time.unscaledTime >= hideAt)
            {
                Hide();
            }

            if (keepVisible)
            {
                targetX = GetVisibleX();
                targetAlpha = 1f;
                hideScheduled = false;
            }

            if (targetAlpha <= 0f) targetX = GetHiddenX();

            var currentPosition = panelTransform.anchoredPosition;
            currentPosition.x = Mathf.MoveTowards(
                currentPosition.x,
                targetX,
                SlideSpeed * Time.unscaledDeltaTime);
            panelTransform.anchoredPosition = currentPosition;

            var fadeDuration = Mathf.Max(0.01f, FadeSeconds);
            promptCanvasGroup.alpha = Mathf.MoveTowards(
                promptCanvasGroup.alpha,
                targetAlpha,
                Time.unscaledDeltaTime / fadeDuration);

            if (Mathf.Approximately(targetX, GetVisibleX()) &&
                !hideScheduled &&
                !keepVisible &&
                Mathf.Abs(panelTransform.anchoredPosition.x - targetX) <= 0.1f)
            {
                hideAt = Time.unscaledTime + VisibleSeconds;
                hideScheduled = true;
            }
        }

        private void Hide()
        {
            targetX = GetHiddenX();
            targetAlpha = 0f;
            hideScheduled = false;
        }

        private static float GetVisibleX()
        {
            return 0f;
        }

        private float GetHiddenX()
        {
            return (panelTransform == null ? 0f : panelTransform.rect.width) + 24f;
        }
    }
}
