using UnityEngine;
using UnityEngine.UI;
using System;
using YC.Domain.State;

namespace YC.Presentation
{
    /// <summary>主界面公共信息和本机盖放牌背的只读投影。</summary>
    public sealed class GameplayMainModules : MonoBehaviour
    {
        [SerializeField] private GameObject[] opponentData;
        [SerializeField] private GameObject[] opponentEmpty;
        [SerializeField] private Text[] opponentName;
        [SerializeField] private Text[] opponentScore;
        [SerializeField] private Text[] opponentHandCount;
        [SerializeField] private Text[] opponentStyleCount;
        [SerializeField] private Image[] opponentColor;
        [SerializeField] private Button[] opponentDetailToggles;
        [SerializeField] private GameObject[] opponentDetailPanels;
        [SerializeField] private RectTransform[] opponentSeats;
        [SerializeField] private RectTransform cityRegion;
        [SerializeField] private RawImage cityBoardArtwork;
        [SerializeField] private UiOpponentDetailInput playerCityLayout;
        [SerializeField] private Sprite detailToggleCollapsed;
        [SerializeField] private Sprite detailToggleExpanded;
        [SerializeField] private Sprite detailToggleDown;
        [SerializeField] private Sprite detailToggleUp;
        [SerializeField] private float detailHeight = 108f;
        [SerializeField] private float expandedDetailHeight = 224f;
        [SerializeField] private RawImage coveredBack;
        [SerializeField] private GameObject coveredEmpty;
        [SerializeField] private Text characterDeckCount;
        [SerializeField] private Text[] localResourceValues;
        [SerializeField] private Text localVoucherValue;
        [SerializeField] private Text discardCountText;
        [SerializeField] private Button discardPreviewButton;
        [SerializeField] private string discardCountFormat = "弃牌 {0}";
        [SerializeField] private string unnamedPlayerFormat = "玩家 {0}";
        private readonly int[] opponentIds = { -1, -1, -1 };
        private readonly int[] detailCounts = new int[3];
        private int expandedPlayerId = -1;
        private Action openDiscardPreview;
        public Text DiscardCountText => discardCountText;

        public void ConfigureDiscardPreview(Action openPreview)
        {
            if (discardPreviewButton != null)
            {
                discardPreviewButton.onClick.RemoveListener(OpenDiscardPreview);
                openDiscardPreview = openPreview;
                if (openDiscardPreview != null)
                    discardPreviewButton.onClick.AddListener(OpenDiscardPreview);
                discardPreviewButton.interactable = openDiscardPreview != null;
            }
        }

        public void RenderDiscardCount(int count)
        {
            if (discardCountText != null)
                discardCountText.text = string.Format(discardCountFormat, Mathf.Max(0, count));
        }

        public void RenderResources(ResourceSet resources)
        {
            if (resources == null || localResourceValues == null || localResourceValues.Length != 4 ||
                localVoucherValue == null) return;
            localResourceValues[0].text = resources.Originium.ToString();
            localResourceValues[1].text = resources.OriginiumShard.ToString();
            localResourceValues[2].text = resources.Iron.ToString();
            localResourceValues[3].text = resources.PureOriginium.ToString();
            localVoucherValue.text = resources.GoldVoucher.ToString();
        }

        private void OpenDiscardPreview() => openDiscardPreview?.Invoke();
        private void Awake()
        {
            if (opponentSeats == null) return;
            for (var i = 0; i < opponentSeats.Length; i++)
            {
                if (opponentDetailToggles == null || i >= opponentDetailToggles.Length ||
                    opponentDetailToggles[i] == null) continue;
                var slot = i;
                opponentDetailToggles[i].onClick.RemoveAllListeners();
                opponentDetailToggles[i].onClick.AddListener(() => ToggleOpponent(slot));
            }
        }

        public bool TryValidateConfiguration(out string reason)
        {
            if (opponentData == null || opponentData.Length != 3 ||
                opponentEmpty == null || opponentEmpty.Length != 3 ||
                opponentName == null || opponentName.Length != 3 ||
                opponentScore == null || opponentScore.Length != 3 ||
                opponentHandCount == null || opponentHandCount.Length != 3 ||
                opponentStyleCount == null || opponentStyleCount.Length != 3 ||
                opponentColor == null || opponentColor.Length != 3 ||
                opponentDetailToggles == null || opponentDetailToggles.Length != 3 ||
                opponentDetailPanels == null || opponentDetailPanels.Length != 3 ||
                opponentSeats == null || opponentSeats.Length != 3 ||
                cityRegion == null || cityBoardArtwork == null || playerCityLayout == null ||
                detailToggleCollapsed == null || detailToggleExpanded == null ||
                detailToggleDown == null || detailToggleUp == null ||
                coveredBack == null || coveredEmpty == null || characterDeckCount == null ||
                localResourceValues == null || localResourceValues.Length != 4 ||
                localVoucherValue == null ||
                discardCountText == null || discardPreviewButton == null)
            {
                reason = "主界面玩家或牌堆投影引用不完整。";
                return false;
            }
            for (var i = 0; i < 3; i++)
            {
                if (opponentData[i] == null || opponentEmpty[i] == null ||
                    opponentName[i] == null || opponentScore[i] == null ||
                    opponentHandCount[i] == null || opponentStyleCount[i] == null ||
                    opponentColor[i] == null)
                {
                    reason = "主界面对手席位 " + (i + 1) + " 引用不完整。";
                    return false;
                }
                if (opponentDetailToggles[i] == null || opponentDetailPanels[i] == null ||
                    opponentSeats[i] == null)
                {
                    reason = "主界面对手明细宿主引用不完整。";
                    return false;
                }
            }
            for (var i = 0; i < localResourceValues.Length; i++)
            {
                if (localResourceValues[i] != null) continue;
                reason = "主界面本机资源栏引用不完整。";
                return false;
            }
            reason = string.Empty;
            return true;
        }

        public void Render(GameState state, GameStateView visible,
            int localPlayerId, CardVisualCatalog catalog)
        {
            if (state == null && visible == null) return;
            var nextOpponent = 0;
            if (visible != null && visible.Players != null)
            {
                foreach (var player in visible.Players)
                {
                    if (player == null || player.PlayerId == localPlayerId) continue;
                    if (nextOpponent >= opponentData.Length) break;
                    RenderOpponent(nextOpponent++, player.PlayerId, player.Name, player.Color,
                        player.Score, player.HandCardCount,
                        player.DeclaredCityStyleIds == null ? 0 : player.DeclaredCityStyleIds.Count);
                }
            }
            else if (state != null && state.Players != null)
            {
                foreach (var player in state.Players)
                {
                    if (player == null || player.PlayerId == localPlayerId) continue;
                    if (nextOpponent >= opponentData.Length) break;
                    RenderOpponent(nextOpponent++, player.PlayerId, player.Name, player.Color,
                        player.Score,
                        player.HandCardIds == null ? 0 : player.HandCardIds.Count,
                        player.DeclaredCityStyles == null ? 0 : player.DeclaredCityStyles.Count);
                }
            }
            for (var i = nextOpponent; i < opponentData.Length; i++)
            {
                if (opponentIds[i] >= 0) ClearOpponentDetailHost(i);
                opponentIds[i] = -1;
                detailCounts[i] = 0;
                opponentData[i].SetActive(false);
                opponentEmpty[i].SetActive(true);
            }
            UpdateExpandedLayout();

            var hasCovered = false;
            var localColor = YC.Domain.Rules.PlayerColor.Red;
            if (visible != null && visible.Players != null)
            {
                foreach (var player in visible.Players)
                {
                    if (player == null || player.PlayerId != localPlayerId) continue;
                    hasCovered = player.HasCoveredCharacterCard;
                    localColor = player.Color;
                    break;
                }
            }
            else
            {
                var local = state == null ? null : state.FindPlayer(localPlayerId);
                hasCovered = local != null && !string.IsNullOrEmpty(local.CoveredCharacterCardId);
                if (local != null) localColor = local.Color;
            }
            var back = hasCovered && catalog != null ? catalog.GetCharacterBack(localColor) : null;
            coveredBack.texture = back;
            coveredBack.gameObject.SetActive(back != null);
            coveredEmpty.SetActive(!hasCovered);
            characterDeckCount.text = visible != null && visible.Decks != null
                ? visible.Decks.CharacterDeckCount.ToString()
                : state == null || state.Decks == null || state.Decks.CharacterDeck == null
                    ? "0" : state.Decks.CharacterDeck.Count.ToString();
            var localState = state == null ? null : state.FindPlayer(localPlayerId);
            var resources = localState == null ? null : localState.Resources;
            RenderResources(resources);
        }

        private void RenderOpponent(int slot, int playerId, string name,
            YC.Domain.Rules.PlayerColor color, int score, int handCount, int styleCount)
        {
            if (opponentIds[slot] != playerId)
            {
                ClearOpponentDetailHost(slot);
                detailCounts[slot] = 0;
            }
            opponentIds[slot] = playerId;
            opponentEmpty[slot].SetActive(false);
            opponentData[slot].SetActive(true);
            opponentName[slot].text = string.IsNullOrEmpty(name)
                ? string.Format(unnamedPlayerFormat, playerId) : name;
            opponentScore[slot].text = score.ToString();
            // 只使用公开数量，不把对手卡 ID、缩略图或详情送到主界面。
            opponentHandCount[slot].text = handCount.ToString();
            opponentStyleCount[slot].text = styleCount.ToString();
            opponentColor[slot].color = UiTheme.GetPlayerColor(color, 1f);
        }

        /// <summary>后续只读投影适配器在此插入 Registry 共用行；当前公开状态无永续条目。</summary>
        public RectTransform GetOpponentDetailHost(int playerId)
        {
            for (var i = 0; i < opponentIds.Length; i++)
            {
                if (opponentIds[i] != playerId || opponentDetailPanels[i] == null) continue;
                return opponentDetailPanels[i].transform.Find("Detail Viewport/Detail Content")
                    as RectTransform;
            }
            return null;
        }

        public void SetOpponentDetailCount(int playerId, int visibleCount)
        {
            for (var i = 0; i < opponentIds.Length; i++)
            {
                if (opponentIds[i] != playerId) continue;
                detailCounts[i] = Mathf.Max(0, visibleCount);
                var empty = opponentDetailPanels[i].transform.Find(
                    "Detail Viewport/Detail Content/No Persistent Effects");
                if (empty != null) empty.gameObject.SetActive(detailCounts[i] == 0);
                UpdateExpandedLayout();
                return;
            }
        }

        private void ClearOpponentDetailHost(int slot)
        {
            if (opponentDetailPanels == null || slot < 0 ||
                slot >= opponentDetailPanels.Length || opponentDetailPanels[slot] == null) return;
            var host = opponentDetailPanels[slot].transform.Find("Detail Viewport/Detail Content");
            if (host == null) return;
            for (var i = host.childCount - 1; i >= 0; i--)
            {
                var child = host.GetChild(i);
                if (child.name == "No Persistent Effects") continue;
                child.gameObject.SetActive(false);
                Destroy(child.gameObject);
            }
        }

        private void ToggleOpponent(int slot)
        {
            if (slot < 0 || slot >= opponentIds.Length || opponentIds[slot] < 0) return;
            expandedPlayerId = expandedPlayerId == opponentIds[slot] ? -1 : opponentIds[slot];
            UpdateExpandedLayout();
        }

        private void UpdateExpandedLayout()
        {
            if (playerCityLayout == null) return;
            var expandedSlot = -1;
            for (var i = 0; i < opponentIds.Length; i++)
                if (opponentIds[i] >= 0 && opponentIds[i] == expandedPlayerId) expandedSlot = i;
            if (expandedSlot < 0) expandedPlayerId = -1;
            var desired = expandedSlot < 0 ? 0f :
                detailCounts[expandedSlot] > 0 ? expandedDetailHeight : detailHeight;
            playerCityLayout.SetExpanded(expandedSlot, desired);
            for (var i = 0; i < opponentSeats.Length; i++)
            {
                if (opponentDetailToggles[i] != null)
                {
                    opponentDetailToggles[i].gameObject.SetActive(opponentIds[i] >= 0);
                    var toggleFace = opponentDetailToggles[i].GetComponent<Image>();
                    if (toggleFace != null) toggleFace.sprite = i == expandedSlot
                        ? detailToggleExpanded : detailToggleCollapsed;
                    var arrow = opponentDetailToggles[i].transform.Find("Toggle Icon");
                    var arrowImage = arrow == null ? null : arrow.GetComponent<Image>();
                    if (arrowImage != null) arrowImage.sprite = i == expandedSlot
                        ? detailToggleUp : detailToggleDown;
                }
            }
        }
    }
}
