using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

namespace YC.Presentation
{
    public static class FontUtility
    {
        private static readonly Dictionary<Font, FontFamily> ManagedFontFamilies = new Dictionary<Font, FontFamily>();
        private static readonly Dictionary<Font, string> ManagedFontOrigins = new Dictionary<Font, string>();
        private static Font cjkFont;
        private static Font latinFont;
        private static UiFontRoles roleFonts;
        private static Object configurationOwner;
        private static bool refreshingTextRenderers;
        private static bool pendingManagedTextRefresh;
        private static bool pendingManagedFontRecreate;

        public static Font GetCjkFont(int fontSize)
        {
            return GetConfiguredFont(cjkFont, "CJK");
        }

        public static Font GetLatinFont(int fontSize)
        {
            return GetConfiguredFont(latinFont, "Latin");
        }

        public static Font GetRoleFont(UiFontRole role)
        {
            if (roleFonts == null || configurationOwner == null)
            {
                throw new System.InvalidOperationException("FontUtility semantic fonts are not configured by FontRefreshDriver.");
            }
            return GetConfiguredFont(roleFonts.Get(role), role.ToString());
        }

        internal static bool IsConfigured => cjkFont != null && latinFont != null && configurationOwner != null;

        internal static void Configure(Font configuredCjkFont, Font configuredLatinFont, Object owner)
        {
            Configure(configuredCjkFont, configuredLatinFont, null, owner);
        }

        internal static void Configure(Font configuredCjkFont, Font configuredLatinFont, UiFontRoles configuredRoles, Object owner)
        {
            if (configuredCjkFont == null || configuredLatinFont == null || owner == null)
            {
                throw new System.InvalidOperationException(
                    "FontUtility requires serialized CJK and Latin fonts plus a live configuration owner.");
            }

            cjkFont = configuredCjkFont;
            latinFont = configuredLatinFont;
            roleFonts = configuredRoles;
            configurationOwner = owner;
            ManagedFontFamilies.Clear();
            ManagedFontOrigins.Clear();
            ManagedFontFamilies[cjkFont] = FontFamily.Cjk;
            ManagedFontOrigins[cjkFont] = "Serialized:CJK";
            ManagedFontFamilies[latinFont] = FontFamily.Latin;
            ManagedFontOrigins[latinFont] = "Serialized:Latin";
            if (roleFonts != null)
            {
                RegisterRole(roleFonts.Regular, FontFamily.Regular, "Serialized:Regular");
                RegisterRole(roleFonts.Emphasis, FontFamily.Emphasis, "Serialized:Emphasis");
                RegisterRole(roleFonts.SpecialWord, FontFamily.SpecialWord, "Serialized:SpecialWord");
                RegisterRole(roleFonts.EffectNumber, FontFamily.EffectNumber, "Serialized:EffectNumber");
                RegisterRole(roleFonts.UiNumber, FontFamily.UiNumber, "Serialized:UiNumber");
                RegisterRole(roleFonts.MissingGlyphFallback, FontFamily.Fallback, "Serialized:Fallback");
            }
        }

        private static void RegisterRole(Font font, FontFamily family, string origin)
        {
            if (font == null) return;
            ManagedFontFamilies[font] = family;
            ManagedFontOrigins[font] = origin;
        }

        internal static void Release(Object owner)
        {
            if (owner == null || configurationOwner != owner)
            {
                return;
            }

            cjkFont = null;
            latinFont = null;
            roleFonts = null;
            configurationOwner = null;
            ManagedFontFamilies.Clear();
            ManagedFontOrigins.Clear();
            pendingManagedTextRefresh = false;
            pendingManagedFontRecreate = false;
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetRuntimeState()
        {
            cjkFont = null;
            latinFont = null;
            roleFonts = null;
            configurationOwner = null;
            ManagedFontFamilies.Clear();
            ManagedFontOrigins.Clear();
            refreshingTextRenderers = false;
            pendingManagedTextRefresh = false;
            pendingManagedFontRecreate = false;
        }

        private static Font GetConfiguredFont(Font font, string familyName)
        {
            if (font == null || configurationOwner == null)
            {
                throw new System.InvalidOperationException(
                    "FontUtility " + familyName +
                    " font is not configured. A serialized FontRefreshDriver must run before UI initialization.");
            }

            return font;
        }

        internal static void OnFontTextureRebuilt(Font font)
        {
            if (font == null || !ManagedFontFamilies.ContainsKey(font))
            {
                return;
            }

            // UnityEngine.UI.Text observes normal atlas rebuilds itself. The shared driver
            // keeps this subscription only to identify managed-font events; expensive
            // hierarchy refreshes are reserved for explicit focus/health recovery.
        }

        internal static void RecreateManagedFonts()
        {
            if (UnityEngine.Application.isPlaying)
            {
                RequestManagedTextRefresh(true);
                return;
            }

            RefreshManagedTextRenderers(true);
        }

        internal static bool HasInvalidManagedFontTexture()
        {
            foreach (var font in ManagedFontFamilies.Keys)
            {
                if (!IsFontTextureValid(font))
                {
                    return true;
                }
            }

            return false;
        }

        internal static string GetManagedFontOrigin(Font font)
        {
            if (font == null)
            {
                return string.Empty;
            }

            string origin;
            return ManagedFontOrigins.TryGetValue(font, out origin) ? origin : string.Empty;
        }

        internal static ManagedFontHealthCheckReport RunManagedFontHealthCheck(bool simulateInvalidTexture)
        {
            var before = CaptureManagedFontSnapshot("BeforeSnapshot");
            var invalidTextureDetected = HasInvalidManagedFontTexture();
            var recreateFonts = simulateInvalidTexture || invalidTextureDetected;
            if (recreateFonts)
            {
                RecreateManagedFonts();
            }

            var after = CaptureManagedFontSnapshot("AfterSnapshot");
            var snapshotBuilder = new StringBuilder();
            snapshotBuilder.AppendLine("长挂机字体自检快照");
            snapshotBuilder.AppendLine("SimulatedInvalidTexture: " + simulateInvalidTexture);
            snapshotBuilder.AppendLine("InvalidManagedTextureDetected: " + invalidTextureDetected);
            snapshotBuilder.AppendLine("RecreatedManagedFonts: " + recreateFonts);
            snapshotBuilder.AppendLine("ManagedFontCountBefore: " + before.ManagedFontCount);
            snapshotBuilder.AppendLine("ManagedTextCountBefore: " + before.ManagedTextCount);
            snapshotBuilder.AppendLine("ManagedFontCountAfter: " + after.ManagedFontCount);
            snapshotBuilder.AppendLine("ManagedTextCountAfter: " + after.ManagedTextCount);
            snapshotBuilder.Append(before.Text);
            snapshotBuilder.Append(after.Text);

            return new ManagedFontHealthCheckReport
            {
                SimulatedInvalidTexture = simulateInvalidTexture,
                InvalidManagedTextureDetected = invalidTextureDetected,
                RecreatedManagedFonts = recreateFonts,
                ManagedFontCountBefore = before.ManagedFontCount,
                ManagedTextCountBefore = before.ManagedTextCount,
                ManagedFontCountAfter = after.ManagedFontCount,
                ManagedTextCountAfter = after.ManagedTextCount,
                Snapshot = snapshotBuilder.ToString()
            };
        }

        internal static void RefreshManagedTextRenderers(bool recreateFonts)
        {
            if (refreshingTextRenderers)
            {
                return;
            }

            refreshingTextRenderers = true;
            try
            {
                var texts = Object.FindObjectsOfType<Text>(true);
                var textCount = texts == null ? 0 : texts.Length;
                var families = textCount > 0 ? new FontFamily[textCount] : null;
                var managed = textCount > 0 ? new bool[textCount] : null;

                for (var i = 0; i < textCount; i++)
                {
                    var text = texts[i];
                    FontFamily family;
                    if (text != null && text.font != null && ManagedFontFamilies.TryGetValue(text.font, out family))
                    {
                        managed[i] = true;
                        families[i] = family;
                    }
                }

                if (textCount == 0)
                {
                    return;
                }

                for (var i = 0; i < textCount; i++)
                {
                    if (!managed[i] || texts[i] == null)
                    {
                        continue;
                    }

                    var text = texts[i];
                    if (recreateFonts)
                    {
                        text.font = GetManagedFont(families[i], text.fontSize);
                    }

                    text.FontTextureChanged();
                    text.SetAllDirty();
                }

                Canvas.ForceUpdateCanvases();
            }
            finally
            {
                refreshingTextRenderers = false;
            }
        }

        internal static void FlushPendingManagedTextRefresh()
        {
            if (!pendingManagedTextRefresh || refreshingTextRenderers)
            {
                return;
            }

            var recreateFonts = pendingManagedFontRecreate;
            pendingManagedTextRefresh = false;
            pendingManagedFontRecreate = false;
            RefreshManagedTextRenderers(recreateFonts);
        }

        private static void RequestManagedTextRefresh(bool recreateFonts)
        {
            pendingManagedTextRefresh = true;
            pendingManagedFontRecreate |= recreateFonts;
        }

        private static Font GetManagedFont(FontFamily family, int size)
        {
            switch (family)
            {
                case FontFamily.Latin: return GetLatinFont(size);
                case FontFamily.Regular: return GetRoleFont(UiFontRole.Regular);
                case FontFamily.Emphasis: return GetRoleFont(UiFontRole.Emphasis);
                case FontFamily.SpecialWord: return GetRoleFont(UiFontRole.SpecialWord);
                case FontFamily.EffectNumber: return GetRoleFont(UiFontRole.EffectNumber);
                case FontFamily.UiNumber: return GetRoleFont(UiFontRole.UiNumber);
                case FontFamily.Fallback: return roleFonts.MissingGlyphFallback;
                default: return GetCjkFont(size);
            }
        }
        private static ManagedFontSnapshot CaptureManagedFontSnapshot(string label)
        {
            var snapshot = new ManagedFontSnapshot();
            snapshot.ManagedFontCount = ManagedFontFamilies.Count;

            var builder = new StringBuilder();
            builder.AppendLine(label + ":");
            builder.AppendLine("TrackedFonts:");

            var listedFonts = new HashSet<Font>();
            AppendTrackedFont(builder, "CjkCache", cjkFont, listedFonts);
            AppendTrackedFont(builder, "LatinCache", latinFont, listedFonts);
            foreach (var pair in ManagedFontFamilies)
            {
                if (pair.Key == null || listedFonts.Contains(pair.Key))
                {
                    continue;
                }

                AppendTrackedFont(builder, "ManagedOnly", pair.Key, listedFonts);
            }

            if (listedFonts.Count == 0)
            {
                builder.AppendLine("- <none>");
            }

            builder.AppendLine("ManagedTexts:");
            var texts = Object.FindObjectsOfType<Text>(true);
            if (texts != null)
            {
                for (var i = 0; i < texts.Length; i++)
                {
                    var text = texts[i];
                    FontFamily family;
                    if (text == null || text.font == null || !ManagedFontFamilies.TryGetValue(text.font, out family))
                    {
                        continue;
                    }

                    snapshot.ManagedTextCount++;
                    builder.AppendLine("- path=" + GetHierarchyPath(text.transform) +
                                       ", family=" + family +
                                       ", fontSize=" + text.fontSize +
                                       ", bestFit=" + text.resizeTextForBestFit +
                                       ", enabled=" + text.enabled +
                                       ", activeInHierarchy=" + text.gameObject.activeInHierarchy +
                                       ", fontId=" + text.font.GetInstanceID() +
                                       ", texture=" + DescribeTexture(GetFontTexture(text.font)) +
                                       ", text=\"" + FormatTextSample(text.text) + "\"");
                }
            }

            if (snapshot.ManagedTextCount == 0)
            {
                builder.AppendLine("- <none>");
            }

            snapshot.Text = builder.ToString();
            return snapshot;
        }

        private static void AppendTrackedFont(StringBuilder builder, string source, Font font, HashSet<Font> listedFonts)
        {
            if (font == null)
            {
                builder.AppendLine("- source=" + source + ", font=<null>");
                return;
            }

            listedFonts.Add(font);
            FontFamily family;
            var tracked = ManagedFontFamilies.TryGetValue(font, out family);
            builder.AppendLine("- source=" + source +
                               ", tracked=" + tracked +
                               ", family=" + (tracked ? family.ToString() : "Unknown") +
                               ", origin=" + GetManagedFontOrigin(font) +
                               ", name=" + font.name +
                               ", id=" + font.GetInstanceID() +
                               ", dynamic=" + font.dynamic +
                               ", material=" + DescribeMaterial(font.material) +
                               ", texture=" + DescribeTexture(GetFontTexture(font)));
        }

        private static bool IsFontTextureValid(Font font)
        {
            return font != null && font.material != null && font.material.mainTexture != null;
        }

        private static Texture GetFontTexture(Font font)
        {
            return font != null && font.material != null
                ? font.material.mainTexture
                : null;
        }

        private static string DescribeMaterial(Material material)
        {
            return material == null
                ? "null"
                : material.name + "#" + material.GetInstanceID();
        }

        private static string DescribeTexture(Texture texture)
        {
            if (texture == null)
            {
                return "null";
            }

            return texture.name +
                   "#" + texture.GetInstanceID() +
                   " (" + texture.width + "x" + texture.height + ")";
        }

        private static string GetHierarchyPath(Transform transform)
        {
            if (transform == null)
            {
                return "<null>";
            }

            var builder = new StringBuilder(transform.name);
            var current = transform.parent;
            while (current != null)
            {
                builder.Insert(0, current.name + "/");
                current = current.parent;
            }

            return builder.ToString();
        }

        private static string FormatTextSample(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return string.Empty;
            }

            var normalized = value.Replace('\r', ' ').Replace('\n', ' ');
            return normalized.Length <= 64
                ? normalized
                : normalized.Substring(0, 64) + "...";
        }

        private enum FontFamily
        {
            Cjk,
            Latin,
            Regular,
            Emphasis,
            SpecialWord,
            EffectNumber,
            UiNumber,
            Fallback
        }

        private sealed class ManagedFontSnapshot
        {
            public int ManagedFontCount;
            public int ManagedTextCount;
            public string Text = string.Empty;
        }
    }

    public sealed class ManagedFontHealthCheckReport
    {
        public bool SimulatedInvalidTexture { get; internal set; }
        public bool InvalidManagedTextureDetected { get; internal set; }
        public bool RecreatedManagedFonts { get; internal set; }
        public int ManagedFontCountBefore { get; internal set; }
        public int ManagedTextCountBefore { get; internal set; }
        public int ManagedFontCountAfter { get; internal set; }
        public int ManagedTextCountAfter { get; internal set; }
        public string Snapshot { get; internal set; }
    }

}
