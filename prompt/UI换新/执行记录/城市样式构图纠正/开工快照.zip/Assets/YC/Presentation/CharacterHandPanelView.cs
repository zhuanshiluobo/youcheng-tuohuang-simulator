using UnityEngine;
using UnityEngine.UI;

namespace YC.Presentation
{
    public sealed class CharacterHandPanelView : MonoBehaviour
    {
        [SerializeField] private CharacterHandPanel controller;
        [SerializeField] private RectTransform root;
        [SerializeField] private RectTransform handCardsRoot;
        [SerializeField] private RectTransform handDropArea;
        [SerializeField] private CharacterHandCardView handCardTemplate;
        [SerializeField] private RectTransform dragGhostTemplate;
        [SerializeField] private RawImage dragGhostImage;
        [SerializeField] private CanvasGroup dragGhostCanvasGroup;

        public CharacterHandPanel Controller => controller;
        public RectTransform Root => root;
        public RectTransform HandCardsRoot => handCardsRoot;
        public Animation HandCardsAnimation =>
            handCardsRoot != null ? handCardsRoot.GetComponent<Animation>() : null;
        public RectTransform HandDropArea => handDropArea;
        public CharacterHandCardView HandCardTemplate => handCardTemplate;
        public RectTransform DragGhostTemplate => dragGhostTemplate;
        public RawImage DragGhostImage => dragGhostImage;
        public CanvasGroup DragGhostCanvasGroup => dragGhostCanvasGroup;

        public bool IsBoundTo(CharacterHandPanel candidate)
        {
            return candidate != null && controller == candidate;
        }

        public bool TryValidateConfiguration(out string reason)
        {
            if (controller == null || root == null || handCardsRoot == null ||
                HandCardsAnimation == null || HandCardsAnimation.clip == null ||
                HandCardsAnimation.GetClip("CharacterHandReturn") == null || handDropArea == null ||
                handCardTemplate == null || dragGhostTemplate == null ||
                dragGhostImage == null || dragGhostCanvasGroup == null)
            {
                reason = "手牌面板固定 View 引用不完整。";
                return false;
            }

            if (!handCardTemplate.TryValidateConfiguration(out reason))
            {
                return false;
            }

            if (handCardTemplate.gameObject.activeSelf || dragGhostTemplate.gameObject.activeSelf)
            {
                reason = "手牌动态模板必须在 Prefab 中默认禁用。";
                return false;
            }

            reason = string.Empty;
            return true;
        }
    }
}
