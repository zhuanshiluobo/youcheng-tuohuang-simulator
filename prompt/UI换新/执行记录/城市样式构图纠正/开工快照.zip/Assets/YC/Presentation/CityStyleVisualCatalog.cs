using System;
using UnityEngine;
using YC.Domain.CityStyles;

namespace YC.Presentation
{
    /// <summary>卡面版本、源矩形和安全区成组配置；这里只映射公开状态，不决定规则。</summary>
    [CreateAssetMenu(menuName = "YC/Presentation/City Style Visual Catalog")]
    public sealed class CityStyleVisualCatalog : ScriptableObject
    {
        [Serializable] public sealed class Card
        {
            public string id, version, artworkPath, atlasId;
            public Rect sourceRect;
            public string trackLayout;
        }
        [Serializable] public sealed class Track
        {
            public string layout, area, sourceKey;
            public Rect safeRect;
        }
        [SerializeField] private Card[] cards = Array.Empty<Card>();
        [SerializeField] private Track[] tracks = Array.Empty<Track>();
        [SerializeField] private Vector2 cardSize = new Vector2(930, 600);
        [SerializeField] private Color[] playerColors = Array.Empty<Color>();
        public Card Find(string id) => Array.Find(cards, c => c.id == id);
        public Rect Bounds(string id, string area)
        {
            var card = Find(id);
            var track = Array.Find(tracks, t => t.layout == (card == null ? "" : card.trackLayout) && t.area == area);
            if (track == null) track = Array.Find(tracks, t => t.layout == "all" && t.area == area);
            if (track == null) return Rect.zero;
            var r = track.safeRect;
            return new Rect(r.x / cardSize.x, 1 - r.yMax / cardSize.y, r.width / cardSize.x, r.height / cardSize.y);
        }
        public Color PlayerColor(int index, Color fallback) => index >= 0 && index < playerColors.Length ? playerColors[index] : fallback;
    }
}
