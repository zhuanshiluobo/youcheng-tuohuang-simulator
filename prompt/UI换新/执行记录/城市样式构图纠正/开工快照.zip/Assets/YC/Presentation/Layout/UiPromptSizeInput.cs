using UnityEngine;
using UnityEngine.UI;

namespace YC.Presentation
{
    /// <summary>提示的静态外框由本容器约束，滑入动画只移动外框内部的原面板。</summary>
    public sealed class UiPromptSizeInput : MonoBehaviour
    {
        [SerializeField] private RectTransform frame;
        [SerializeField] private Text promptText;
        [SerializeField] private float preferredWidth = 520;
        [SerializeField] private float minimumHeight = 82;
        [SerializeField] private float horizontalTextInset = 44;
        [SerializeField] private float verticalTextPadding = 28;
        private bool measureContent;
        public void RefreshContent() { measureContent = true; RefreshInput(); }
        private void LateUpdate() { if (measureContent) RefreshInput(); }
        private void RefreshInput()
        {
            if (frame == null || promptText == null) return;
            var input = frame.GetComponent<LayoutElement>();
            if (input == null) return;
            input.preferredWidth = preferredWidth;
            var settings = promptText.GetGenerationSettings(new Vector2(
                Mathf.Max(1, frame.rect.width - horizontalTextInset), 0));
            input.preferredHeight = Mathf.Max(minimumHeight, Mathf.Ceil(
                promptText.cachedTextGeneratorForLayout.GetPreferredHeight(promptText.text, settings) /
                promptText.pixelsPerUnit + verticalTextPadding));
        }
    }
}
