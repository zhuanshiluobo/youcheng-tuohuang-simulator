using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace YC.Presentation
{
    /// <summary>
    /// 公共建设卡与特殊建设卡共用的尺寸、拖拽虚影移动和城市槽位解析。
    /// </summary>
    internal static class FacilityCardDragUtility
    {
        public const float CardWidth = 99f;
        public const float CardHeight = 141f;
        public const float CardImageInset = 3f;

        private static readonly Color CardBackground = new Color(0.09f, 0.07f, 0.045f, 0.72f);

        // 拖动成员只需要空的显示锚点，不能复制来源按钮的子模型或输入组件。
        public static Image CreateDragMemberImage(RectTransform parent)
        {
            var member = new GameObject("拖动成员", typeof(RectTransform), typeof(Image));
            member.transform.SetParent(parent, false);
            var image = member.GetComponent<Image>();
            image.raycastTarget = false;
            return image;
        }

        public static RectTransform CreateDragGhost(
            RectTransform canvas,
            RectTransform source,
            Texture texture,
            string fallbackLabel,
            Font fallbackFont,
            CardDragGhostLayout layout)
        {
            if (canvas == null || source == null)
            {
                return null;
            }

            var ghostObject = new GameObject(
                "建设卡拖动虚影",
                typeof(RectTransform),
                typeof(Canvas),
                typeof(RawImage),
                typeof(CanvasGroup));
            ghostObject.transform.SetParent(canvas, false);
            ghostObject.transform.SetAsLastSibling();

            var dragCanvas = ghostObject.GetComponent<Canvas>();
            dragCanvas.overrideSorting = true;
            dragCanvas.sortingOrder = GameplayUiLayers.ContentDrag;

            var ghost = ghostObject.GetComponent<RectTransform>();
            layout.RootLayout.ApplyTo(ghost);
            ghost.sizeDelta = source.rect.size;

            var image = ghostObject.GetComponent<RawImage>();
            image.texture = texture;
            image.color = texture == null ? CardBackground : Color.white;
            image.raycastTarget = false;

            var canvasGroup = ghostObject.GetComponent<CanvasGroup>();
            canvasGroup.alpha = 0.82f;
            canvasGroup.interactable = false;
            canvasGroup.blocksRaycasts = false;

            if (texture == null && !string.IsNullOrEmpty(fallbackLabel))
            {
                AddFallbackLabel(ghost, fallbackLabel, fallbackFont, layout);
            }

            return ghost;
        }

        public static void MoveDragGhost(RectTransform ghost, PointerEventData eventData)
        {
            if (ghost == null || eventData == null)
            {
                return;
            }

            var canvasRect = ghost.parent as RectTransform;
            if (canvasRect == null)
            {
                return;
            }

            Vector2 localPoint;
            if (RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    canvasRect,
                    eventData.position,
                    eventData.pressEventCamera,
                    out localPoint))
            {
                ghost.anchoredPosition = localPoint;
            }
        }

        public static int ResolveCityBoardSlotIndex(
            PointerEventData eventData, RectTransform boardArtwork)
        {
            if (eventData == null || boardArtwork == null || !boardArtwork.gameObject.activeInHierarchy)
            {
                return -1;
            }

            var hit = eventData.pointerCurrentRaycast.gameObject;
            // A persistent bar or an open page above the board owns this release.
            if (hit != null && !hit.transform.IsChildOf(boardArtwork)) return -1;
            var canvas = boardArtwork.GetComponentInParent<Canvas>();
            var root = canvas == null ? null : canvas.rootCanvas;
            var camera = root == null || root.renderMode == RenderMode.ScreenSpaceOverlay
                ? null : root.worldCamera;
            return CityBoardSlotLayout.TryGetSlotIndex(
                boardArtwork, eventData.position, camera, out var slotIndex)
                ? slotIndex : -1;
        }

        // Effect-card drags may originate in a page canvas above the legacy city board.
        // Keep that existing route, but validate against the same artwork geometry.
        public static int ResolveCityBoardSlotIndex(PointerEventData eventData)
        {
            if (eventData == null) return -1;
            var hit = eventData.pointerCurrentRaycast.gameObject;
            var hitCanvas = hit == null ? null : hit.GetComponentInParent<Canvas>();
            if (hitCanvas != null && hitCanvas.sortingOrder >= GameplayUiLayers.PersistentBars)
                return -1;

            var targets = UnityEngine.Object.FindObjectsOfType<CityBoardSlotDropTarget>();
            for (var i = 0; i < targets.Length; i++)
            {
                var target = targets[i];
                var artwork = target == null ? null : target.transform.parent as RectTransform;
                if (target == null || !target.isActiveAndEnabled || artwork == null ||
                    !artwork.gameObject.activeInHierarchy) continue;
                var canvas = artwork.GetComponentInParent<Canvas>();
                var root = canvas == null ? null : canvas.rootCanvas;
                var camera = root == null || root.renderMode == RenderMode.ScreenSpaceOverlay
                    ? null : root.worldCamera;
                if (CityBoardSlotLayout.TryGetSlotIndex(
                        artwork, eventData.position, camera, out var slotIndex) &&
                    slotIndex == target.SlotIndex) return slotIndex;
            }
            return -1;
        }

        public static void DestroyDragGhost(ref RectTransform ghost)
        {
            if (ghost == null)
            {
                return;
            }

            var ghostObject = ghost.gameObject;
            ghost = null;
            if (UnityEngine.Application.isPlaying)
            {
                UnityEngine.Object.Destroy(ghostObject);
            }
            else
            {
                UnityEngine.Object.DestroyImmediate(ghostObject);
            }
        }

        private static void AddFallbackLabel(
            RectTransform parent,
            string value,
            Font font,
            CardDragGhostLayout layout)
        {
            var textObject = new GameObject(
                "Fallback",
                typeof(RectTransform),
                typeof(Text),
                typeof(Outline));
            textObject.transform.SetParent(parent, false);
            var rect = textObject.GetComponent<RectTransform>();
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = layout.FallbackOffsetMin;
            rect.offsetMax = layout.FallbackOffsetMax;

            var text = textObject.GetComponent<Text>();
            text.text = value ?? string.Empty;
            text.font = font;
            text.fontSize = 12;
            text.fontStyle = FontStyle.Bold;
            text.color = UiTheme.ValueText;
            text.alignment = TextAnchor.MiddleCenter;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 8;
            text.resizeTextMaxSize = 12;
            text.raycastTarget = false;

            var outline = textObject.GetComponent<Outline>();
            outline.effectColor = UiTheme.DarkShadowLight;
            outline.effectDistance = layout.FallbackOutlineDistance;
        }

    }

    /// <summary>
    /// Reusable pointer interaction for cards. It owns click classification,
    /// drag lifecycle validation, and suppression of the click emitted after a drag.
    /// Card-specific visuals and gameplay behavior stay in the configured callbacks.
    /// </summary>
    public sealed class CardPointerInteraction : MonoBehaviour,
        IPointerDownHandler,
        IPointerClickHandler,
        IPointerEnterHandler,
        IPointerExitHandler,
        IBeginDragHandler,
        IDragHandler,
        IEndDragHandler
    {
        private Button button;
        private Action singleClick;
        private Action doubleClick;
        private Func<bool> canBeginDrag;
        private Action<PointerEventData> beginDrag;
        private Action<PointerEventData> drag;
        private Action<PointerEventData> endDrag;
        private Action cancelDrag;
        private Action pointerEnter;
        private Action pointerExit;
        private bool dragging;
        private bool pointerInside;
        private bool suppressClickForCurrentPress;

        public void ConfigureClick(
            Button configuredButton,
            Action configuredSingleClick,
            Action configuredDoubleClick)
        {
            button = configuredButton;
            singleClick = configuredSingleClick;
            doubleClick = configuredDoubleClick;
        }

        public void ConfigureDrag(
            Func<bool> configuredCanBeginDrag,
            Action<PointerEventData> configuredBeginDrag,
            Action<PointerEventData> configuredDrag,
            Action<PointerEventData> configuredEndDrag,
            Action configuredCancelDrag = null)
        {
            if (button == null)
            {
                button = GetComponent<Button>();
            }

            canBeginDrag = configuredCanBeginDrag;
            beginDrag = configuredBeginDrag;
            drag = configuredDrag;
            endDrag = configuredEndDrag;
            cancelDrag = configuredCancelDrag;
        }

        public void ConfigureHover(Action configuredPointerEnter, Action configuredPointerExit)
        {
            pointerEnter = configuredPointerEnter;
            pointerExit = configuredPointerExit;
        }

        public void OnPointerDown(PointerEventData eventData)
        {
            if (IsLeftPointer(eventData))
            {
                suppressClickForCurrentPress = false;
            }
        }

        public void OnPointerClick(PointerEventData eventData)
        {
            if (button == null || !button.IsInteractable() || !IsLeftPointer(eventData))
            {
                return;
            }

            if (suppressClickForCurrentPress)
            {
                suppressClickForCurrentPress = false;
                return;
            }

            if (eventData.clickCount >= 2)
            {
                doubleClick?.Invoke();
                return;
            }

            singleClick?.Invoke();
        }

        public void OnPointerEnter(PointerEventData eventData)
        {
            pointerInside = true;
            pointerEnter?.Invoke();
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            pointerInside = false;
            pointerExit?.Invoke();
        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            dragging = button != null &&
                       button.IsInteractable() &&
                       IsLeftPointer(eventData) &&
                       canBeginDrag != null &&
                       canBeginDrag();
            if (!dragging)
            {
                return;
            }

            suppressClickForCurrentPress = true;
            beginDrag?.Invoke(eventData);
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (dragging && eventData != null)
            {
                drag?.Invoke(eventData);
            }
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            if (!dragging)
            {
                return;
            }

            dragging = false;
            endDrag?.Invoke(eventData);
        }

        private void OnDisable()
        {
            if (dragging)
            {
                dragging = false;
                cancelDrag?.Invoke();
            }

            if (pointerInside)
            {
                pointerInside = false;
                pointerExit?.Invoke();
            }
        }

        private static bool IsLeftPointer(PointerEventData eventData)
        {
            return eventData != null && eventData.button == PointerEventData.InputButton.Left;
        }
    }
}
